import { Injectable } from '@angular/core';

import { HttpClient, HttpHeaders } from '@angular/common/http';

import { environment } from '../../environments/environment';

import { Order } from '../models/order';

import { AuthService } from '../core/services/auth';

@Injectable({
  providedIn: 'root',
})
export class OrderService {
  // API URL
  // Base URL for order APIs

  private api = `${environment.apiUrl}/orders`;

  constructor(
    // HTTP client for API calls

    private http: HttpClient,

    // Auth service for JWT token

    private auth: AuthService,
  ) {}

  // AUTH HEADERS
  // Attach Authorization token
  // to secured requests

  private getHeaders() {
    return new HttpHeaders({
      Authorization: `Bearer ${this.auth.token}`,
    });
  }

  // PLACE ORDER
  // Create new order

  placeOrder(order: any) {
    return this.http.post(
      this.api,

      order,

      {
        headers: this.getHeaders(),
      },
    );
  }

  // USER ORDERS
  // Fetch logged-in user orders

  getOrders(userId: number) {
    return this.http.get(
      `${this.api}/user/${userId}`,

      {
        headers: this.getHeaders(),
      },
    );
  }

  //  ADMIN ORDERS
  // Fetch all orders for admin

  getAllOrders() {
    return this.http.get<any[]>(
      this.api,

      {
        headers: this.getHeaders(),
      },
    );
  }

  //  DELETE ORDER
  // Delete order by id

  deleteOrder(orderId: number) {
    return this.http.delete(
      `${this.api}/${orderId}`,

      {
        headers: this.getHeaders(),
      },
    );
  }
}
