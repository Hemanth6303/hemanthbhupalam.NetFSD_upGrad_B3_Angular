import { Injectable } from '@angular/core';

import { HttpClient, HttpHeaders } from '@angular/common/http';

import { environment } from '../../environments/environment';

import { AuthService } from '../core/services/auth';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  //  API URL
  // Base URL for user/admin APIs

  private api = `${environment.apiUrl}/auth`;

  constructor(
    // HTTP client for API calls

    private http: HttpClient,

    // Auth service for JWT token

    private auth: AuthService,
  ) {}

  // HEADERS
  // Attach Authorization token
  // to secured API requests

  private getHeaders() {
    return new HttpHeaders({
      Authorization: `Bearer ${this.auth.token}`,
    });
  }

  //  GET USERS
  // Fetch all users

  getUsers() {
    return this.http.get<any[]>(
      this.api,

      {
        headers: this.getHeaders(),
      },
    );
  }

  // UPDATE ROLE
  // Update user role

  updateRole(userId: number, role: string) {
    return this.http.put(
      `${this.api}/${userId}/role`,

      // Request body

      { role },

      {
        headers: this.getHeaders(),
      },
    );
  }
}
