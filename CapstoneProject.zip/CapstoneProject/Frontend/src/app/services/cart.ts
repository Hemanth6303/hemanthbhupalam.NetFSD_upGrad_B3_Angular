import { Injectable, inject, PLATFORM_ID } from '@angular/core';

import { isPlatformBrowser } from '@angular/common';

import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class CartService {
  //  PLATFORM
  // Used for SSR-safe browser checks

  private platformId = inject(PLATFORM_ID);

  // INITIAL CART
  // Default empty cart

  private initialCart: any[] = [];

  //  BEHAVIOR SUBJECT
  // Stores cart state reactively

  private cartSubject = new BehaviorSubject<any[]>(this.initialCart);

  //  OBSERVABLE
  // Observable used across application

  cart$ = this.cartSubject.asObservable();

  constructor() {
    // RESTORE CART
    // Load cart from localStorage
    // only in browser

    if (isPlatformBrowser(this.platformId)) {
      const storedCart = localStorage.getItem('cart');

      if (storedCart) {
        this.cartSubject.next(JSON.parse(storedCart));
      }
    }
  }

  //  GET ITEMS
  // Returns current cart items

  get items() {
    return this.cartSubject.value;
  }

  //  SAVE CART
  // Save cart into localStorage
  // and update observable state

  private saveCart(items: any[]) {
    // Save only in browser

    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem(
        'cart',

        JSON.stringify(items),
      );
    }

    // Update reactive cart state

    this.cartSubject.next(items);
  }

  // ADD PRODUCT
  // Add product into cart

  add(p: any) {
    // Create copy of cart items

    const items = [...this.items];

    // Check existing product

    const existing = items.find((x) => x.productId === p.productId);

    // INCREASE QUANTITY
    // If product already exists

    if (existing) {
      existing.quantity++;
    }

    // ADD NEW PRODUCT
    else {
      items.push({
        productId: p.productId,

        name: p.name,

        price: p.price,

        quantity: 1,
      });
    }

    // Save updated cart

    this.saveCart(items);
  }

  //  UPDATE QUANTITY
  // Update item quantity

  updateQuantity(index: number, qty: number) {
    const items = [...this.items];

    items[index].quantity = qty;

    this.saveCart(items);
  }

  // REMOVE PRODUCT
  // Remove item from cart

  remove(index: number) {
    const items = [...this.items];

    items.splice(index, 1);

    this.saveCart(items);
  }

  //  CLEAR CART
  // Remove all cart items

  clear() {
    // Remove localStorage data

    if (isPlatformBrowser(this.platformId)) {
      localStorage.removeItem('cart');
    }

    // Reset cart state

    this.cartSubject.next([]);
  }

  //  TOTAL
  // Calculate total cart amount

  total() {
    return this.items.reduce(
      (sum, i) => sum + i.price * i.quantity,

      0,
    );
  }
}
