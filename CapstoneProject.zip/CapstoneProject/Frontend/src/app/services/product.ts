import { Injectable } from '@angular/core';

import { Product } from '../models/product';

import { HttpClient } from '@angular/common/http';

import { environment } from '../../environments/environment';

import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ProductService {
  // API URL
  // Base URL for product APIs

  private api = `${environment.apiUrl}/products`;

  constructor(
    // HTTP client for API calls

    private http: HttpClient,
  ) {}

  // GET ALL PRODUCTS
  // Fetch all products

  getAll(): Observable<Product[]> {
    return this.http.get<Product[]>(this.api);
  }

  // GET PRODUCT BY ID
  // Fetch single product details

  getById(id: number): Observable<Product> {
    return this.http.get<Product>(`${this.api}/${id}`);
  }

  //  DELETE PRODUCT
  // Delete product by id

  delete(id: number): Observable<any> {
    return this.http.delete(`${this.api}/${id}`);
  }

  // CREATE PRODUCT
  // Create new product

  create(form: any): Observable<any> {
    return this.http.post(this.api, form);
  }

  // UPDATE PRODUCT
  // Update existing product

  update(productId: number, form: any): Observable<any> {
    return this.http.put(
      `${this.api}/${productId}`,

      form,
    );
  }

  // PAGINATION + SEARCH
  // Fetch paginated products
  // with optional search

  getPaged(
    page: number = 1,

    pageSize: number = 10,

    search: string = '',
  ): Observable<any> {
    return this.http.get<any>(`${this.api}?page=${page}&pageSize=${pageSize}&search=${search}`);
  }
}
