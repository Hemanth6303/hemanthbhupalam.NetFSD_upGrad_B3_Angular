// Import Routes from Angular Router
import { Routes } from '@angular/router';

// Import route guards
import { authGuard } from './core/guards/auth-guard';
import { adminGuard } from './core/guards/admin-guard';

// Define application routes
export const routes: Routes = [
  // Home page route
  {
    path: '',
    loadComponent: () => import('./pages/home/home').then((m) => m.HomeComponent),
  },

  // Product list page
  {
    path: 'products',
    loadComponent: () =>
      import('./components/product-list/product-list').then((m) => m.ProductListComponent),
  },

  // Product details page
  {
    path: 'products/:id',
    loadComponent: () =>
      import('./components/product-details/product-details').then((m) => m.ProductDetailsComponent),
  },

  // Cart page
  {
    path: 'cart',
    loadComponent: () => import('./components/cart/cart').then((m) => m.CartComponent),
  },

  // Checkout page
  {
    path: 'checkout',
    canActivate: [authGuard],
    loadComponent: () => import('./components/checkout/checkout').then((m) => m.CheckoutComponent),
  },

  // USER ORDERS PAGE
  {
    path: 'orders',
    canActivate: [authGuard],
    loadComponent: () => import('./components/orders/orders').then((m) => m.OrdersComponent),
  },

  // Login page
  {
    path: 'login',
    loadComponent: () => import('./pages/login/login').then((m) => m.LoginComponent),
  },

  // Register page
  {
    path: 'register',
    loadComponent: () => import('./pages/register/register').then((m) => m.RegisterComponent),
  },

  // Admin section
  {
    path: 'admin',
    canActivate: [adminGuard],

    loadComponent: () =>
      import('./pages/admin/admin-dashboard/admin-dashboard').then(
        (m) => m.AdminDashboardComponent,
      ),

    children: [
      {
        path: 'products',
        loadComponent: () =>
          import('./pages/admin/admin-products/admin-products').then(
            (m) => m.AdminProductsComponent,
          ),
      },

      {
        path: 'orders',
        loadComponent: () =>
          import('./pages/admin/admin-orders/admin-orders').then((m) => m.AdminOrdersComponent),
      },

      {
        path: 'users',
        loadComponent: () =>
          import('./pages/admin/admin-users/admin-users').then((m) => m.AdminUsersComponent),
      },
    ],
  },
];
