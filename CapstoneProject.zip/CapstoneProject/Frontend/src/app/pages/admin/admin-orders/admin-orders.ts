import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';

import { CommonModule } from '@angular/common';

import { OrderService } from '../../../services/order';

@Component({
  selector: 'app-admin-orders',

  standalone: true,

  imports: [CommonModule],

  templateUrl: './admin-orders.html',

  styleUrl: './admin-orders.css',

  // PERFORMANCE OPTIMIZATION
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminOrdersComponent implements OnInit {
  //  ORDERS
  orders: any[] = [];

  //  LOADING
  loading = false;

  //  MESSAGE
  message = '';

  messageType: 'success' | 'error' | 'warning' | '' = '';

  constructor(
    private orderService: OrderService,

    private cdr: ChangeDetectorRef,
  ) {}

  //  INIT
  ngOnInit(): void {
    this.loadOrders();
  }

  // LOAD ORDERS
  loadOrders() {
    this.loading = true;

    this.cdr.detectChanges();

    this.orderService.getAllOrders().subscribe({
      next: (res: any) => {
        this.orders = res;

        this.loading = false;

        this.cdr.detectChanges();
      },

      error: () => {
        this.loading = false;

        this.message = 'Failed to load orders';

        this.messageType = 'error';

        this.cdr.detectChanges();
      },
    });
  }

  // TRACK BY
  trackByOrder(index: number, item: any) {
    return item.orderId;
  }

  // DELETE ORDER

  deleteOrder(orderId: number): void {
    this.loading = true;

    this.cdr.detectChanges();

    this.orderService.deleteOrder(orderId).subscribe({
      next: () => {
        // Remove deleted order from UI

        this.orders = this.orders.filter((x) => x.orderId !== orderId);

        this.loading = false;

        this.message = 'Order deleted successfully';

        this.messageType = 'success';

        this.cdr.detectChanges();
      },

      error: () => {
        this.loading = false;

        this.message = 'Failed to delete order';

        this.messageType = 'error';

        this.cdr.detectChanges();
      },
    });
  }
}
