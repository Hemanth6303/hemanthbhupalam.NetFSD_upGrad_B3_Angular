import { CommonModule } from '@angular/common';

import { ChangeDetectionStrategy, ChangeDetectorRef, Component } from '@angular/core';

import { FormsModule } from '@angular/forms';

import { UserService } from '../../../services/user';

@Component({
  selector: 'app-admin-users',

  imports: [CommonModule, FormsModule],

  templateUrl: './admin-users.html',

  styleUrl: './admin-users.css',

  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminUsersComponent {
  // USERS

  users: any[] = [];

  //  LOADING

  loading = false;

  //MESSAGE

  message = '';

  messageType: 'success' | 'error' | '' = '';

  constructor(
    private userService: UserService,

    private cdr: ChangeDetectorRef,
  ) {}

  //  INIT

  ngOnInit(): void {
    this.loadUsers();
  }

  // LOAD USERS

  loadUsers(): void {
    this.loading = true;

    this.userService.getUsers().subscribe({
      next: (res) => {
        this.users = res;

        this.loading = false;

        this.cdr.detectChanges();
      },

      error: () => {
        this.loading = false;

        this.message = 'Failed to load users';

        this.messageType = 'error';

        this.cdr.detectChanges();
      },
    });
  }

  //  UPDATE ROLE

  updateRole(userId: number, role: string): void {
    this.userService.updateRole(userId, role).subscribe({
      next: () => {
        this.message = 'Role updated successfully';

        this.messageType = 'success';

        this.cdr.detectChanges();
      },

      error: () => {
        this.message = 'Failed to update role';

        this.messageType = 'error';

        this.cdr.detectChanges();
      },
    });
  }
}
