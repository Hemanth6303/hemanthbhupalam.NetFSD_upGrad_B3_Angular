import { CommonModule } from '@angular/common';

import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';

import { ProductService } from '../../../services/product';

import { FormsModule } from '@angular/forms';

import { Product } from '../../../models/product';

@Component({
  standalone: true,

  selector: 'app-admin-products',

  imports: [CommonModule, FormsModule],

  templateUrl: './admin-products.html',

  styleUrl: './admin-products.css',

  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminProductsComponent implements OnInit {
  // STATE

  products: Product[] = [];

  form: Partial<Product> = {};

  loading = false;

  // Message state
  message = '';

  messageType: 'success' | 'error' | 'warning' | '' = '';

  constructor(
    private service: ProductService,

    private cdr: ChangeDetectorRef,
  ) {}

  //  INIT

  ngOnInit(): void {
    this.load();
  }

  // LOAD PRODUCTS

  load(): void {
    this.loading = true;

    this.cdr.detectChanges();

    this.service.getAll().subscribe({
      next: (res: any) => {
        this.products = res.items ? res.items : res;

        this.loading = false;

        this.cdr.detectChanges();
      },

      error: () => {
        this.loading = false;

        this.message = 'Failed to load products';

        this.messageType = 'error';

        this.cdr.detectChanges();
      },
    });
  }

  //  SAVE

  save(): void {
    console.log('FORM DATA:', this.form);

    if (!this.form.name || !this.form.price || !this.form.categoryName) {
      this.message = 'Please fill all required fields';

      this.messageType = 'warning';

      this.cdr.detectChanges();

      return;
    }

    this.loading = true;

    this.cdr.detectChanges();

    // UPDATE

    if (this.form.productId) {
      this.service.update(this.form.productId, this.form).subscribe({
        next: () => {
          this.loading = false;

          this.message = 'Product updated successfully';

          this.messageType = 'success';

          this.resetForm();

          this.load();

          this.cdr.detectChanges();
        },

        error: () => {
          this.loading = false;

          this.message = 'Update failed';

          this.messageType = 'error';

          this.cdr.detectChanges();
        },
      });
    }

    // CREATE
    else {
      this.service.create(this.form).subscribe({
        next: () => {
          this.loading = false;

          this.message = 'Product saved successfully';

          this.messageType = 'success';

          this.resetForm();

          this.load();

          this.cdr.detectChanges();
        },

        error: () => {
          this.loading = false;

          this.message = 'Create failed';

          this.messageType = 'error';

          this.cdr.detectChanges();
        },
      });
    }
  }

  //  EDIT

  edit(p: Product): void {
    this.form = { ...p };

    this.cdr.detectChanges();
  }

  //  DELETE

  delete(id: number): void {
    if (!confirm('Are you sure you want to delete this product?')) {
      return;
    }

    this.service.delete(id).subscribe({
      next: () => {
        this.message = 'Product deleted';

        this.messageType = 'success';

        this.load();

        this.cdr.detectChanges();
      },

      error: () => {
        this.message = 'Delete failed';

        this.messageType = 'error';

        this.cdr.detectChanges();
      },
    });
  }

  //  RESET

  resetForm(): void {
    this.form = {};

    this.cdr.detectChanges();
  }
}
