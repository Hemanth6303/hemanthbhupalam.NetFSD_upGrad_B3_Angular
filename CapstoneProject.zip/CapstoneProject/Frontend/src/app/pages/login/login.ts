import { Component, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';

import { AuthService } from '../../core/services/auth';
import { CommonModule } from '@angular/common';

import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css',

  // Performance optimization
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LoginComponent {
  //  FORM
  form = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),

    password: new FormControl('', [Validators.required, Validators.minLength(6)]),
  });

  // STATES
  loading = false;

  message = '';
  messageType: 'success' | 'error' | '' = '';

  constructor(
    private auth: AuthService,
    private router: Router,
    private cdr: ChangeDetectorRef,
  ) {}

  //  SUBMIT
  submit() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.message = '';
    this.messageType = '';

    this.loading = true;

    // Update UI
    this.cdr.markForCheck();

    this.auth.login(this.form.value).subscribe({
      next: (user: any) => {
        this.loading = false;

        this.message = 'Login successful';
        this.messageType = 'success';

        // Refresh UI
        this.cdr.markForCheck();

        setTimeout(() => {
          if (user.role === 'Admin') {
            this.router.navigate(['/admin']);
          } else {
            this.router.navigate(['/']);
          }
        }, 1000);
      },

      error: (err) => {
        this.loading = false;

        // Show backend error message
        this.message = err?.error?.message || 'Invalid Email or Password';

        this.messageType = 'error';

        // Refresh UI
        this.cdr.markForCheck();
      },
    });
  }
}
