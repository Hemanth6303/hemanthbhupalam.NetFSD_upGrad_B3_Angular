import { Component, OnInit, ChangeDetectorRef } from '@angular/core';

import { ProductService } from '../../services/product';

import { Product } from '../../models/product';

import { RouterLink } from '@angular/router';

import { CommonModule, CurrencyPipe } from '@angular/common';

import { CartService } from '../../services/cart';

@Component({
  selector: 'app-home',

  standalone: true,

  imports: [RouterLink, CurrencyPipe, CommonModule],

  templateUrl: './home.html',

  styleUrl: './home.css',
})
export class HomeComponent implements OnInit {
  //  PRODUCTS

  products: Product[] = [];

  //  LOADING

  loading: boolean = true;

  // ERROR MESSAGE

  errorMessage: string = '';

  // SUCCESS MESSAGE

  successMessage: string = '';

  constructor(
    private productService: ProductService,

    private cart: CartService,

    private cdr: ChangeDetectorRef,
  ) {}

  //INIT

  ngOnInit(): void {
    this.loadProducts();
  }

  //  LOAD PRODUCTS

  loadProducts(): void {
    this.loading = true;

    this.productService.getAll().subscribe({
      next: (res: any) => {
        const items = res.items ? res.items : res;

        // Show top 5 expensive products

        this.products = items

          .sort((a: Product, b: Product) => b.price - a.price)

          .slice(0, 5);

        this.loading = false;

        this.cdr.detectChanges();
      },

      error: () => {
        this.errorMessage = 'Failed to load products';

        this.loading = false;

        this.cdr.detectChanges();
      },
    });
  }

  // ADD TO CART

  addToCart(product: Product): void {
    // Add product into cart

    this.cart.add(product);

    // Success message

    this.successMessage = `${product.name} added to cart`;

    this.cdr.detectChanges();

    // Auto hide after 2 seconds

    setTimeout(() => {
      this.successMessage = '';

      this.cdr.detectChanges();
    }, 2000);
  }
}
