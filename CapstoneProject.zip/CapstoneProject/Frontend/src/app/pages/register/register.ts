import { Component, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';

import { ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';

import { CommonModule } from '@angular/common';
import { AuthService } from '../../core/services/auth';
import { Router } from '@angular/router';

@Component({
  standalone: true,
  selector: 'app-register',
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './register.html',
  styleUrl: './register.css',

  // Performance optimization
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RegisterComponent {
  //  FORM
  form = new FormGroup({
    name: new FormControl('', [Validators.required, Validators.minLength(3)]),

    email: new FormControl('', [Validators.required, Validators.email]),

    password: new FormControl('', [Validators.required, Validators.minLength(6)]),
  });

  // STATES
  loading = false;

  message = '';
  messageType: 'success' | 'error' | '' = '';

  constructor(
    private auth: AuthService,
    private router: Router,
    private cdr: ChangeDetectorRef,
  ) {}

  // SUBMIT
  submit() {
    // Show validation errors
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    // Clear old messages
    this.message = '';
    this.messageType = '';

    this.loading = true;

    // Refresh UI
    this.cdr.markForCheck();

    // Form data
    const data = this.form.value;

    // Register API call
    this.auth.register(data).subscribe({
      next: () => {
        this.loading = false;

        // Success message
        this.message = 'Registration successful';
        this.messageType = 'success';

        // Refresh UI
        this.cdr.markForCheck();

        // Redirect to login page
        setTimeout(() => {
          this.router.navigate(['/login']);
        }, 1000);
      },

      error: (err) => {
        this.loading = false;

        // Backend error message
        this.message = err?.error?.message || 'Registration failed';

        this.messageType = 'error';

        // Refresh UI
        this.cdr.markForCheck();
      },
    });
  }
}
