// Import Component decorator and signal
import { Component, signal } from '@angular/core';

// Import RouterOutlet for routing
import { RouterOutlet } from '@angular/router';

// Import shared components
import { NavbarComponent } from './shared/components/navbar/navbar';
import { FooterComponent } from './shared/components/footer/footer';

// Root component configuration
@Component({
  // Standalone component
  standalone: true,

  // HTML selector used in index.html
  selector: 'app-root',

  // Components/directives used inside this component
  imports: [NavbarComponent, RouterOutlet, FooterComponent],

  // HTML template file
  templateUrl: './app.html',

  // CSS file
  styleUrl: './app.css',
})

// Root application component
export class AppComponent {
  // Application title using Angular signal
  readonly title = signal('shop-ez-angular');
}
