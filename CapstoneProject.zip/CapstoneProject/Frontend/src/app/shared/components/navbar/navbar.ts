import { Component, OnDestroy } from '@angular/core';
import { CartService } from '../../../services/cart';
import { AuthService } from '../../../core/services/auth';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Subject, takeUntil } from 'rxjs';

@Component({
  standalone: true,
  selector: 'app-navbar',
  imports: [CommonModule, RouterModule],
  templateUrl: './navbar.html',
  styleUrl: './navbar.css',
})
export class NavbarComponent implements OnDestroy {
  // CART COUNT
  // Holds number of items in cart
  cartCount = 0;

  // CLEANUP SUBJECT
  // Used to unsubscribe automatically (prevents memory leaks)
  private destroy$ = new Subject<void>();

  constructor(
    public auth: AuthService, // Used in template for user state
    private cart: CartService, // Provides cart observable
  ) {
    //  SUBSCRIBE TO CART
    // Updates cart count whenever cart changes
    this.cart.cart$
      .pipe(takeUntil(this.destroy$)) //prevents memory leaks
      .subscribe((items) => {
        this.cartCount = items.length;
      });
  }

  //LOGOUT
  logout() {
    this.auth.logout();
  }

  // CLEANUP
  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
