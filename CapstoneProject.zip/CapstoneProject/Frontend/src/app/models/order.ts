export interface Order {
  orderId: number;
  userId: number;
  totalAmount: number;
}