export interface AuthResponse {
  userId: number;
  name: string;
  email: string;
  role: string;
  token: string;
}