// Import ApplicationConfig and global error listener
import { ApplicationConfig, provideBrowserGlobalErrorListeners } from '@angular/core';

// Import router provider
import { provideRouter } from '@angular/router';

// Import HTTP client providers
import { provideHttpClient, withFetch, withInterceptors } from '@angular/common/http';

// Import hydration support
import { provideClientHydration, withEventReplay } from '@angular/platform-browser';

// Import application routes
import { routes } from './app.routes';

// Import custom interceptors
import { jwtInterceptor } from './core/interceptors/jwt-interceptor';
import { errorInterceptor } from './core/interceptors/error-interceptor';

// Main application configuration
export const appConfig: ApplicationConfig = {
  // Global providers
  providers: [
    // Handle global browser errors
    provideBrowserGlobalErrorListeners(),

    // Register application routes
    provideRouter(routes),

    // Enable client hydration with event replay
    provideClientHydration(withEventReplay()),

    // Configure HTTP client
    provideHttpClient(
      // Use Fetch API
      withFetch(),

      // Register HTTP interceptors
      withInterceptors([
        // Add JWT token to requests
        jwtInterceptor,

        // Handle API errors globally
        errorInterceptor,
      ]),
    ),
  ],
};
