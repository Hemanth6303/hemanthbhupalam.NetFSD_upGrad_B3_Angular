import { Component, OnInit, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';

import { CommonModule } from '@angular/common';

import { OrderService } from '../../services/order';

@Component({
  standalone: true,

  selector: 'app-orders',

  imports: [CommonModule],

  templateUrl: './orders.html',

  styleUrl: './orders.css',

  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OrdersComponent implements OnInit {
  // USER ORDERS

  orders: any[] = [];

  // LOADING STATE

  loading = true;

  // ERROR MESSAGE

  errorMessage = '';

  constructor(
    private orderService: OrderService,
    private cdr: ChangeDetectorRef,
  ) {}

  //  INIT

  ngOnInit(): void {
    this.loadOrders();
  }

  // LOAD ORDERS

  loadOrders(): void {
    this.loading = true;

    this.errorMessage = '';

    // GET USER ID FROM LOCAL STORAGE

    const user = JSON.parse(localStorage.getItem('user') || '{}');

    const userId = user.userId;

    this.orderService.getOrders(userId).subscribe({
      next: (response: any) => {
        this.orders = response || [];

        this.loading = false;

        this.cdr.detectChanges();
      },

      error: (err) => {
        console.error(err);

        this.loading = false;

        this.orders = [];

        this.errorMessage = 'Failed to load orders';

        this.cdr.detectChanges();
      },
    });
  }
}
