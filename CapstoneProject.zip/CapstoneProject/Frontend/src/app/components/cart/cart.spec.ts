import { ComponentFixture, TestBed } from '@angular/core/testing';

import { of } from 'rxjs';

import { provideRouter } from '@angular/router';

import { CartComponent } from './cart';

import { CartService } from '../../services/cart';

describe('CartComponent', () => {
  let component: CartComponent;

  let fixture: ComponentFixture<CartComponent>;

  let cartServiceSpy: jasmine.SpyObj<CartService>;

  beforeEach(async () => {
    // MOCK CART SERVICE

    cartServiceSpy = jasmine.createSpyObj('CartService', ['remove', 'total', 'updateQuantity'], {
      cart$: of([
        {
          name: 'Laptop',
          price: 50000,
          quantity: 1,
        },
      ]),
    });

    //  MOCK TOTAL

    cartServiceSpy.total.and.returnValue(50000);

    //  TEST CONFIG

    await TestBed.configureTestingModule({
      imports: [CartComponent],

      providers: [
        provideRouter([]),

        {
          provide: CartService,
          useValue: cartServiceSpy,
        },
      ],
    }).compileComponents();

    // CREATE COMPONENT

    fixture = TestBed.createComponent(CartComponent);

    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  //  COMPONENT CREATION

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // NGONINIT

  it('should load cart items on init', (done) => {
    component.items$.subscribe((items) => {
      expect(items.length).toBe(1);

      expect(items[0].name).toBe('Laptop');

      done();
    });
  });

  // REMOVE

  it('should remove item from cart', () => {
    component.remove(0);

    expect(cartServiceSpy.remove).toHaveBeenCalledWith(0);
  });

  //  TOTAL

  it('should return total cart amount', () => {
    const total = component.total();

    expect(total).toBe(50000);

    expect(cartServiceSpy.total).toHaveBeenCalled();
  });

  // UPDATE QUANTITY

  it('should update quantity', () => {
    component.updateQuantity(0, 3);

    expect(cartServiceSpy.updateQuantity).toHaveBeenCalledWith(0, 3);
  });

  //  MIN QUANTITY

  it('should set minimum quantity to 1', () => {
    component.updateQuantity(0, 0);

    expect(cartServiceSpy.updateQuantity).toHaveBeenCalledWith(0, 1);
  });

  // MAX QUANTITY

  it('should set maximum quantity to 8', () => {
    component.updateQuantity(0, 10);

    expect(cartServiceSpy.updateQuantity).toHaveBeenCalledWith(0, 8);
  });
});
