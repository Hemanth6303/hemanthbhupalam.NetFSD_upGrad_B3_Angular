import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';

import { CartService } from '../../services/cart';

import { CommonModule } from '@angular/common';

import { RouterModule } from '@angular/router';

import { FormsModule } from '@angular/forms';

import { Observable } from 'rxjs';

//CART ITEM MODEL

export interface CartItem {
  // Product name

  name: string;

  // Product price

  price: number;

  // Product quantity

  quantity: number;
}

@Component({
  selector: 'app-cart',

  standalone: true,

  imports: [CommonModule, RouterModule, FormsModule],

  templateUrl: './cart.html',

  styleUrl: './cart.css',

  //  PERFORMANCE
  // Reduces unnecessary change detection

  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CartComponent implements OnInit {
  // CART ITEMS
  // Observable cart data

  items$!: Observable<CartItem[]>;

  constructor(
    // Cart service

    private cart: CartService,

    // Required because OnPush is used

    private cdr: ChangeDetectorRef,
  ) {}

  // INIT
  // Load cart observable

  ngOnInit(): void {
    this.items$ = this.cart.cart$;
  }

  // REMOVE ITEM
  // Removes product from cart

  remove(index: number): void {
    this.cart.remove(index);

    // Refresh UI manually

    this.cdr.detectChanges();
  }

  // TOTAL PRICE
  // Calculates total cart amount

  total(): number {
    return this.cart.total();
  }

  //  UPDATE QUANTITY
  // Updates cart item quantity

  updateQuantity(index: number, quantity: number): void {
    // Prevent invalid quantity

    if (quantity < 1) {
      quantity = 1;
    }

    // Maximum quantity limit

    if (quantity > 8) {
      quantity = 8;
    }

    // Update quantity in cart

    this.cart.updateQuantity(index, quantity);

    // Refresh UI manually

    this.cdr.detectChanges();
  }
}
