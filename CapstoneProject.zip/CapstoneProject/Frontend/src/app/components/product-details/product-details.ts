import { Component, OnInit, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';

import { CartService } from '../../services/cart';

import { ProductService } from '../../services/product';

import { ActivatedRoute, RouterModule } from '@angular/router';

import { CommonModule } from '@angular/common';

import { Product } from '../../models/product';

@Component({
  selector: 'app-product-details',

  standalone: true,

  imports: [CommonModule, RouterModule],

  templateUrl: './product-details.html',

  styleUrl: './product-details.css',

  //  PERFORMANCE
  // Improves performance by reducing unnecessary
  // change detection cycles

  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ProductDetailsComponent implements OnInit {
  // PRODUCT DATA
  // Stores selected product details

  product!: Product;

  // MESSAGE
  // Used for success/error messages

  message = '';

  messageType: 'success' | 'error' | '' = '';

  constructor(
    // Used to read product id from URL

    private route: ActivatedRoute,

    // Product API service

    private service: ProductService,

    // Cart service

    private cart: CartService,

    // Required for OnPush UI updates

    private cdr: ChangeDetectorRef,
  ) {}

  //  INIT
  // Loads product details when page opens

  ngOnInit() {
    // Subscribe to route params

    this.route.paramMap.subscribe((params) => {
      // Extract product id from URL

      const id = Number(params.get('id'));

      // Fetch product details from API

      this.service.getById(id).subscribe({
        // SUCCESS

        next: (res) => {
          // Store API response

          this.product = res;

          // Refresh UI manually because
          // OnPush strategy is used

          this.cdr.detectChanges();
        },

        //  ERROR

        error: () => {
          // Display error message

          this.message = 'Failed to load product';

          this.messageType = 'error';

          // Refresh UI

          this.cdr.detectChanges();

          // Auto hide message after 3 seconds

          setTimeout(() => {
            this.message = '';

            this.messageType = '';

            this.cdr.detectChanges();
          }, 3000);
        },
      });
    });
  }

  // ADD TO CART
  // Adds selected product into cart

  addToCart() {
    // Add product to cart

    this.cart.add(this.product);

    // Show success message

    this.message = 'Product added to cart';

    this.messageType = 'success';

    // Refresh UI

    this.cdr.detectChanges();

    // Auto hide message after 3 seconds

    setTimeout(() => {
      this.message = '';

      this.messageType = '';

      this.cdr.detectChanges();
    }, 3000);
  }
}
