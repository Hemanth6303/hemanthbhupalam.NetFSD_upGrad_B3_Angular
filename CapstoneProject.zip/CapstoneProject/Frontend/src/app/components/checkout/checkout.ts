import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';

import { CommonModule } from '@angular/common';

import { Router, RouterModule } from '@angular/router';

import { Observable, take } from 'rxjs';

import { FormsModule } from '@angular/forms';

import { CartService } from '../../services/cart';

import { OrderService } from '../../services/order';

//  CART ITEM MODEL

export interface CartItem {
  productId: number;

  name: string;

  price: number;

  quantity: number;
}

@Component({
  selector: 'app-checkout',

  standalone: true,

  imports: [CommonModule, FormsModule, RouterModule],

  templateUrl: './checkout.html',

  styleUrl: './checkout.css',

  // PERFORMANCE

  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CheckoutComponent implements OnInit {
  // CART ITEMS

  items$!: Observable<CartItem[]>;

  //FORM FIELDS

  customerName = '';

  address = '';

  paymentMode = '';

  phoneNumber = '';

  //  VALIDATION

  submitted = false;

  loading = false;

  // MESSAGE

  message = '';

  messageType: 'success' | 'error' | '' = '';

  constructor(
    // Cart service

    private cart: CartService,

    // Order service

    private order: OrderService,

    // Router

    private router: Router,

    private cdr: ChangeDetectorRef,
  ) {}

  //  INIT

  ngOnInit(): void {
    this.items$ = this.cart.cart$;
  }

  //  TOTAL

  getTotal(): number {
    return this.cart.total();
  }

  // PLACE ORDER

  placeOrder(): void {
    this.submitted = true;

    // VALIDATION

    if (!this.customerName.trim() || !this.address.trim() || !this.paymentMode) {
      this.message = 'Please fill all fields';

      this.messageType = 'error';

      this.cdr.detectChanges();

      this.hideMessage();

      return;
    }

    this.loading = true;

    this.cdr.detectChanges();

    // GET CART ITEMS

    this.items$.pipe(take(1)).subscribe((items) => {
      // Prevent empty cart

      if (!items || items.length === 0) {
        this.message = 'Cart is empty';

        this.messageType = 'error';

        this.loading = false;

        this.cdr.detectChanges();

        this.hideMessage();

        return;
      }

      // GET USER ID

      const user = JSON.parse(localStorage.getItem('user') || '{}');

      const userId = user.userId;

      //  ORDER PAYLOAD

      const orderData = {
        userId: userId,

        customerName: this.customerName,

        totalAmount: this.getTotal(),

        status: 'Pending',

        orderItems: items.map((item) => ({
          productId: item.productId,

          productName: item.name,

          quantity: item.quantity,

          price: item.price,

          totalAmount: item.price * item.quantity,
        })),
      };

      // API CALL

      this.order.placeOrder(orderData).subscribe({
        //  SUCCESS

        next: () => {
          this.message = 'Order placed successfully';

          this.messageType = 'success';

          // Clear cart

          this.cart.clear();

          this.loading = false;

          this.cdr.detectChanges();

          this.hideMessage();

          // Redirect after delay

          setTimeout(() => {
            this.router.navigate(['/']);
          }, 1000);
        },

        //  ERROR

        error: () => {
          this.loading = false;

          this.message = 'Something went wrong';

          this.messageType = 'error';

          this.cdr.detectChanges();

          this.hideMessage();
        },
      });
    });
  }

  //  AUTO HIDE MESSAGE

  hideMessage(): void {
    setTimeout(() => {
      this.message = '';

      this.messageType = '';

      this.cdr.detectChanges();
    }, 3000);
  }
}
