import { Component, OnInit, ChangeDetectorRef, OnDestroy } from '@angular/core';

import { Product } from '../../models/product';

import { CartService } from '../../services/cart';

import { ProductService } from '../../services/product';

import { CommonModule } from '@angular/common';

import { RouterModule } from '@angular/router';

import { FormsModule } from '@angular/forms';

import { Subject, takeUntil } from 'rxjs';

import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

@Component({
  selector: 'app-product-list',

  standalone: true,

  imports: [CommonModule, RouterModule, FormsModule],

  templateUrl: './product-list.html',

  styleUrl: './product-list.css',
})
export class ProductListComponent implements OnInit, OnDestroy {
  //PRODUCTS

  products: Product[] = [];

  // PAGINATION

  page = 1;

  pageSize = 10;

  totalPages = 1;

  // SEARCH

  search = '';

  private searchSubject = new Subject<string>();

  // DESTROY

  private destroy$ = new Subject<void>();

  //  LOADING

  loading = false;

  errorMessage = '';

  //  MESSAGE

  message = '';

  messageType: 'success' | 'error' | '' = '';

  constructor(
    private service: ProductService,

    private cart: CartService,

    private cdr: ChangeDetectorRef,
  ) {}

  //  INIT

  ngOnInit(): void {
    // Initial load

    this.load();

    // Search with debounce

    this.searchSubject
      .pipe(
        debounceTime(500),

        distinctUntilChanged(),

        switchMap((value) => {
          this.search = value;

          this.page = 1;

          this.loading = true;

          this.errorMessage = '';

          this.cdr.detectChanges();

          return this.service.getPaged(this.page, this.pageSize, this.search);
        }),

        takeUntil(this.destroy$),
      )
      .subscribe({
        next: (res) => {
          this.products = res.items || [];

          this.totalPages = res.totalPages || 1;

          this.loading = false;

          this.cdr.detectChanges();
        },

        error: () => {
          this.loading = false;

          this.products = [];

          this.errorMessage = 'Failed to load products';

          this.message = 'Failed to load products';

          this.messageType = 'error';

          this.cdr.detectChanges();

          // Auto hide message

          setTimeout(() => {
            this.message = '';

            this.messageType = '';

            this.cdr.detectChanges();
          }, 3000);
        },
      });
  }

  // LOAD PRODUCTS

  load(): void {
    this.loading = true;

    this.errorMessage = '';

    this.service
      .getPaged(this.page, this.pageSize, this.search)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (res) => {
          this.products = res.items || [];

          this.totalPages = res.totalPages || 1;

          this.loading = false;

          this.cdr.detectChanges();
        },

        error: () => {
          this.loading = false;

          this.products = [];

          this.errorMessage = 'Failed to load products';

          this.message = 'Failed to load products';

          this.messageType = 'error';

          this.cdr.detectChanges();

          // Auto hide message

          setTimeout(() => {
            this.message = '';

            this.messageType = '';

            this.cdr.detectChanges();
          }, 3000);
        },
      });
  }

  // ================= SEARCH =================

  onSearchChange(value: string): void {
    this.searchSubject.next(value);
  }

  // ================= NEXT PAGE =================

  next(): void {
    if (this.page < this.totalPages) {
      this.page++;

      this.load();
    }
  }

  // ================= PREVIOUS PAGE =================

  prev(): void {
    if (this.page > 1) {
      this.page--;

      this.load();
    }
  }

  // ================= TRACK BY =================

  trackById(index: number, item: Product): number {
    return item.productId;
  }

  // ================= ADD TO CART =================

  addToCart(product: Product): void {
    this.cart.add(product);

    this.message = 'Product added to cart';

    this.messageType = 'success';

    this.cdr.detectChanges();

    // Auto hide message after 3 seconds

    setTimeout(() => {
      this.message = '';

      this.messageType = '';

      this.cdr.detectChanges();
    }, 3000);
  }

  // ================= DESTROY =================

  ngOnDestroy(): void {
    this.destroy$.next();

    this.destroy$.complete();
  }
}
