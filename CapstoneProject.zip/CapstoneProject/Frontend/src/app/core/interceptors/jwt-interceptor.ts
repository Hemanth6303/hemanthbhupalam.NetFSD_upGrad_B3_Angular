import { HttpInterceptorFn } from '@angular/common/http';

import { AuthService } from '../services/auth';

import { inject, PLATFORM_ID } from '@angular/core';

import { isPlatformBrowser } from '@angular/common';

export const jwtInterceptor: HttpInterceptorFn = (req, next) => {
  // DEPENDENCIES
  // Inject AuthService
  // to access JWT token

  const auth = inject(AuthService);

  // Inject platform id
  // for SSR safety

  const platformId = inject(PLATFORM_ID);

  // SSR CHECK
  // Prevent accessing browser-only APIs
  // like localStorage during SSR

  if (!isPlatformBrowser(platformId)) {
    return next(req);
  }

  //  GET TOKEN
  // Read JWT token from AuthService

  const token = auth.token;

  // ATTACH TOKEN
  // If token exists,
  // clone request and attach
  // Authorization header

  if (token) {
    const authReq = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`,
      },
    });

    // Send modified request

    return next(authReq);
  }

  // NO TOKEN
  // Send original request
  // without Authorization header

  return next(req);
};
