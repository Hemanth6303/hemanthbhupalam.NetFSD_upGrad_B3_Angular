import { HttpInterceptorFn } from '@angular/common/http';

import { catchError } from 'rxjs/operators';

import { throwError } from 'rxjs';

import { inject, PLATFORM_ID } from '@angular/core';

import { isPlatformBrowser } from '@angular/common';

export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  // DEPENDENCIES

  // Inject platform id
  // for SSR safety

  const platformId = inject(PLATFORM_ID);

  //  HANDLE REQUEST

  return next(req).pipe(
    // GLOBAL ERROR HANDLING

    catchError((err) => {
      // DEFAULT MESSAGE

      let message = 'Something went wrong';

      // STATUS-BASED HANDLING

      switch (err.status) {
        // NETWORK ERROR
        // Backend/server not reachable

        case 0:
          message = 'Server not reachable';

          break;

        // UNAUTHORIZED
        // Invalid token or not logged in

        case 401:
          message = 'Unauthorized access';

          break;

        // FORBIDDEN
        // User does not have permission

        case 403:
          message = 'Access denied';

          break;

        //  SERVER ERROR
        // Internal backend error

        case 500:
          message = 'Server error occurred';

          break;

        // CUSTOM BACKEND MESSAGE

        default:
          // Use backend message if available

          if (err?.error?.message) {
            message = err.error.message;
          }

          break;
      }

      //  SHOW ERROR MESSAGE
      // Show toast only in browser

      if (isPlatformBrowser(platformId)) {
        console.error(message);
      }

      //  RE-THROW ERROR
      // Allows components to handle
      // the error if needed

      return throwError(() => err);
    }),
  );
};
