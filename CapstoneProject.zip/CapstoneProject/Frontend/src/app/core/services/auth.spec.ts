import { TestBed } from '@angular/core/testing';

import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { PLATFORM_ID } from '@angular/core';

import { AuthService } from './auth';

import { environment } from '../../../environments/environment';

describe('AuthService', () => {
  let service: AuthService;

  let httpMock: HttpTestingController;

  //  MOCK USER

  const mockUser = {
    userId: 1,
    name: 'Hemanth',
    email: 'hemanth@gmail.com',
    token: 'mock-jwt-token',
    role: 'Admin',
  };

  // BEFORE EACH

  beforeEach(() => {
    localStorage.clear();

    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],

      providers: [
        {
          provide: PLATFORM_ID,
          useValue: 'browser',
        },
      ],
    });

    service = TestBed.inject(AuthService);

    httpMock = TestBed.inject(HttpTestingController);
  });

  // AFTER EACH

  afterEach(() => {
    httpMock.verify();

    localStorage.clear();
  });

  // CREATE SERVICE

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  //  LOGIN TEST

  it('should login user and store in localStorage', () => {
    const loginData = {
      email: 'hemanth@gmail.com',
      password: '123456',
    };

    service.login(loginData).subscribe((response) => {
      expect(response).toEqual(mockUser);

      expect(service.currentUser).toEqual(mockUser);

      expect(localStorage.getItem('user')).toContain('mock-jwt-token');
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/auth/login`);

    expect(req.request.method).toBe('POST');

    req.flush(mockUser);
  });

  //  REGISTER TEST

  it('should register user', () => {
    const registerData = {
      name: 'Hemanth',
      email: 'hemanth@gmail.com',
      password: '123456',
    };

    service.register(registerData).subscribe((response) => {
      expect(response).toEqual({
        message: 'User registered successfully',
      });
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/auth/register`);

    expect(req.request.method).toBe('POST');

    req.flush({
      message: 'User registered successfully',
    });
  });

  //  LOGOUT TEST

  it('should logout user', () => {
    localStorage.setItem('user', JSON.stringify(mockUser));

    service['userSubject'].next(mockUser);

    service.logout();

    expect(localStorage.getItem('user')).toBeNull();

    expect(service.currentUser).toBeNull();
  });

  //TOKEN TEST

  it('should return token', () => {
    localStorage.setItem('user', JSON.stringify(mockUser));

    expect(service.token).toBe('mock-jwt-token');
  });

  // CURRENT USER TEST

  it('should return current user', () => {
    service['userSubject'].next(mockUser);

    expect(service.currentUser).toEqual(mockUser);
  });

  // RESTORE USER TEST

  it('should restore user from localStorage', () => {
    localStorage.setItem('user', JSON.stringify(mockUser));

    TestBed.resetTestingModule();

    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],

      providers: [
        {
          provide: PLATFORM_ID,
          useValue: 'browser',
        },
      ],
    });

    const restoredService = TestBed.inject(AuthService);

    expect(restoredService.currentUser).toEqual(mockUser);
  });

  //  LOGIN API URL TEST

  it('should call correct login API URL', () => {
    const loginData = {
      email: 'test@gmail.com',
      password: '123456',
    };

    service.login(loginData).subscribe();

    const req = httpMock.expectOne(`${environment.apiUrl}/auth/login`);

    expect(req.request.url).toBe(`${environment.apiUrl}/auth/login`);

    req.flush(mockUser);
  });

  // REGISTER API URL TEST

  it('should call correct register API URL', () => {
    const registerData = {
      name: 'Test',
      email: 'test@gmail.com',
      password: '123456',
    };

    service.register(registerData).subscribe();

    const req = httpMock.expectOne(`${environment.apiUrl}/auth/register`);

    expect(req.request.url).toBe(`${environment.apiUrl}/auth/register`);

    req.flush({});
  });
});
