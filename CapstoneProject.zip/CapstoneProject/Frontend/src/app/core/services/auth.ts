import { Injectable, Inject, PLATFORM_ID } from '@angular/core';

import { isPlatformBrowser } from '@angular/common';

import { environment } from '../../../environments/environment';

import { BehaviorSubject, tap } from 'rxjs';

import { HttpClient } from '@angular/common/http';

import { User } from '../../models/user';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  //  API URL
  // Base URL for authentication APIs

  private api = `${environment.apiUrl}/auth`;

  // USER STATE
  // Stores currently logged-in user

  private userSubject = new BehaviorSubject<User | null>(null);

  // Observable used across application

  user$ = this.userSubject.asObservable();

  constructor(
    // HTTP client for API calls

    private http: HttpClient,

    // Platform id for SSR check

    @Inject(PLATFORM_ID)
    private platformId: Object,
  ) {
    // RESTORE USER
    // Restore logged-in user
    // after page refresh

    if (this.isBrowser()) {
      const user = localStorage.getItem('user');

      if (user) {
        this.userSubject.next(JSON.parse(user));
      }
    }
  }

  // CURRENT USER
  // Returns current logged-in user

  get currentUser(): User | null {
    return this.userSubject.value;
  }

  //  PLATFORM CHECK
  // Prevent localStorage access during SSR

  private isBrowser(): boolean {
    return isPlatformBrowser(this.platformId);
  }

  // LOGIN
  // Authenticate user
  // and store JWT token

  login(data: any) {
    return this.http.post<User>(`${this.api}/login`, data).pipe(
      tap((user) => {
        // Store user in localStorage

        if (this.isBrowser()) {
          localStorage.setItem('user', JSON.stringify(user));
        }

        // Update global auth state

        this.userSubject.next(user);
      }),
    );
  }

  // REGISTER
  // Register new user

  register(data: any) {
    return this.http.post(`${this.api}/register`, data);
  }

  // LOGOUT
  // Clear user session

  logout() {
    // Remove user from localStorage

    if (this.isBrowser()) {
      localStorage.removeItem('user');
    }

    // Reset auth state

    this.userSubject.next(null);
  }

  // TOKEN GETTER
  // Safely returns JWT token

  get token(): string | null {
    if (this.isBrowser()) {
      return JSON.parse(localStorage.getItem('user') || '{}')?.token || null;
    }

    return null;
  }
}
