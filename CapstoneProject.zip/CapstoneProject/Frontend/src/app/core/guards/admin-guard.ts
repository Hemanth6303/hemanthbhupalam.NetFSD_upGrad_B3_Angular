import { CanActivateFn, Router } from '@angular/router';

import { inject, PLATFORM_ID } from '@angular/core';

import { isPlatformBrowser } from '@angular/common';

export const adminGuard: CanActivateFn = () => {
  // DEPENDENCIES
  // Inject Router for navigation

  const router = inject(Router);

  // Inject platform id for SSR check

  const platformId = inject(PLATFORM_ID);

  //  SSR CHECK
  // Prevent localStorage access
  // during server-side rendering

  if (!isPlatformBrowser(platformId)) {
    return false;
  }

  //GET USER
  // Read user data from localStorage

  const userData = localStorage.getItem('user');

  // Convert JSON string into object

  const user = userData ? JSON.parse(userData) : null;

  //  ROLE CHECK
  // Allow access only for Admin users

  if (user?.role === 'Admin') {
    return true;
  }

  // ACCESS DENIED
  // Redirect non-admin users
  // to home page

  router.navigate(['/']);

  return false;
};
