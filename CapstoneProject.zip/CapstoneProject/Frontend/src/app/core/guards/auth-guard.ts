import { CanActivateFn, Router } from '@angular/router';

import { inject, PLATFORM_ID } from '@angular/core';

import { isPlatformBrowser } from '@angular/common';

export const authGuard: CanActivateFn = () => {
  // DEPENDENCIES
  // Inject Router for navigation

  const router = inject(Router);

  // Inject platform id for SSR check

  const platformId = inject(PLATFORM_ID);

  // SSR CHECK
  // Prevent localStorage access
  // during server-side rendering

  if (!isPlatformBrowser(platformId)) {
    return false;
  }

  //  GET USER
  // Read user data from localStorage

  const userData = localStorage.getItem('user');

  // USER CHECK
  // If user does not exist,
  // redirect to login page

  if (!userData) {
    router.navigate(['/login']);

    return false;
  }

  // SAFE PARSE
  // Safely convert JSON string
  // into JavaScript object

  let user = null;

  try {
    user = JSON.parse(userData);
  } catch {
    user = null;
  }

  // TOKEN CHECK
  // Allow access only if token exists

  if (user?.token) {
    return true;
  }

  // INVALID USER
  // Invalid token or malformed user data

  router.navigate(['/login']);

  return false;
};
