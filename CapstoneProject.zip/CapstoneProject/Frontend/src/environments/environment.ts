export const environment = {
  production: false,

  apiUrl: 'http://localhost:5139/api', // your backend port
};
