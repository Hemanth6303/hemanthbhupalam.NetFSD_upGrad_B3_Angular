﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using Moq;

using OrderService.Controllers;
using OrderService.DTOs;
using OrderService.Services.Interfaces;

namespace OrderService.Tests.Controllers
{
    public class OrdersControllerTests
    {
        private readonly Mock<IOrderService>
            _serviceMock;

        private readonly Mock<ILogger<OrdersController>>
            _loggerMock;

        private readonly OrdersController
            _controller;

        public OrdersControllerTests()
        {
            _serviceMock =
                new Mock<IOrderService>();

            _loggerMock =
                new Mock<ILogger<OrdersController>>();

            _controller =
                new OrdersController(
                    _serviceMock.Object,
                    _loggerMock.Object);
        }

        //  GET ALL ORDERS 

        [Fact]
        public async Task GetAllOrders_Should_Return_Ok()
        {
            _serviceMock
                .Setup(x =>
                    x.GetAllOrdersAsync())
                .ReturnsAsync(
                    new List<OrderDto>());

            var result =
                await _controller.GetAllOrders();

            Assert.IsType<OkObjectResult>(result);
        }

        // GET ORDERS BY USER 

        [Fact]
        public async Task GetOrdersByUserId_Should_Return_Ok()
        {
            _serviceMock
                .Setup(x =>
                    x.GetOrdersByUserIdAsync(1))
                .ReturnsAsync(
                    new List<OrderDto>());

            var result =
                await _controller
                    .GetOrdersByUserId(1);

            Assert.IsType<OkObjectResult>(result);
        }

        //GET ORDER BY ID SUCCESS 

        [Fact]
        public async Task GetOrderById_Should_Return_Ok()
        {
            _serviceMock
                .Setup(x =>
                    x.GetOrderByIdAsync(1))
                .ReturnsAsync(
                    new OrderDto());

            var result =
                await _controller
                    .GetOrderById(1);

            Assert.IsType<OkObjectResult>(result);
        }

        // GET ORDER BY ID FAILED

        [Fact]
        public async Task GetOrderById_Should_Return_NotFound()
        {
            _serviceMock
                .Setup(x =>
                    x.GetOrderByIdAsync(1))
                .ReturnsAsync((OrderDto?)null);

            var result =
                await _controller
                    .GetOrderById(1);

            Assert.IsType<NotFoundObjectResult>(
                result);
        }

        //  CREATE ORDER 

        [Fact]
        public async Task CreateOrder_Should_Return_Ok()
        {
            var dto =
                new OrderDto
                {
                    OrderId = 1,
                    CustomerName = "Hemanth"
                };

            _serviceMock
                .Setup(x =>
                    x.CreateOrderAsync(dto))
                .ReturnsAsync(dto);

            var result =
                await _controller
                    .CreateOrder(dto);

            Assert.IsType<OkObjectResult>(result);
        }

        //UPDATE STATUS SUCCESS 

        [Fact]
        public async Task UpdateOrderStatus_Should_Return_Ok()
        {
            _serviceMock
                .Setup(x =>
                    x.UpdateOrderStatusAsync(
                        1,
                        "Delivered"))
                .ReturnsAsync(true);

            var result =
                await _controller
                    .UpdateOrderStatus(
                        1,
                        "Delivered");

            Assert.IsType<OkObjectResult>(result);
        }

        //  UPDATE STATUS FAILED 

        [Fact]
        public async Task UpdateOrderStatus_Should_Return_NotFound()
        {
            _serviceMock
                .Setup(x =>
                    x.UpdateOrderStatusAsync(
                        1,
                        "Delivered"))
                .ReturnsAsync(false);

            var result =
                await _controller
                    .UpdateOrderStatus(
                        1,
                        "Delivered");

            Assert.IsType<NotFoundObjectResult>(
                result);
        }

        //  DELETE SUCCESS 

        [Fact]
        public async Task DeleteOrder_Should_Return_Ok()
        {
            _serviceMock
                .Setup(x =>
                    x.DeleteOrderAsync(1))
                .ReturnsAsync(true);

            var result =
                await _controller
                    .DeleteOrder(1);

            Assert.IsType<OkObjectResult>(result);
        }

        // DELETE FAILED 

        [Fact]
        public async Task DeleteOrder_Should_Return_NotFound()
        {
            _serviceMock
                .Setup(x =>
                    x.DeleteOrderAsync(1))
                .ReturnsAsync(false);

            var result =
                await _controller
                    .DeleteOrder(1);

            Assert.IsType<NotFoundObjectResult>(
                result);
        }
    }
}