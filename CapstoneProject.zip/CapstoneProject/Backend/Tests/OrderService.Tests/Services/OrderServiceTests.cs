﻿using System.Net;

using Moq;
using Moq.Protected;

using OrderService.DTOs;
using OrderService.Entities;
using OrderService.Repositories.Interfaces;
using OrderService.Services.Implementations;

namespace OrderService.Tests.Services
{
    public class OrderServiceTests
    {
        private readonly Mock<IOrderRepository>
            _repositoryMock;

        private readonly Mock<IHttpClientFactory>
            _httpClientFactoryMock;

        private readonly OrderService.Services.Implementations.OrderService
            _service;

        public OrderServiceTests()
        {
            _repositoryMock =
                new Mock<IOrderRepository>();

            _httpClientFactoryMock =
                new Mock<IHttpClientFactory>();

            _service =
                new OrderService.Services.Implementations.OrderService(
                    _repositoryMock.Object,
                    _httpClientFactoryMock.Object);
        }

        // GET ALL ORDERS 

        [Fact]
        public async Task GetAllOrdersAsync_Should_Return_Data()
        {
            _repositoryMock
                .Setup(x =>
                    x.GetAllOrdersAsync())
                .ReturnsAsync(
                    new List<Order>());

            var result =
                await _service
                    .GetAllOrdersAsync();

            Assert.NotNull(result);
        }

        //  GET ORDER BY ID 

        [Fact]
        public async Task GetOrderByIdAsync_Should_Return_Order()
        {
            _repositoryMock
                .Setup(x =>
                    x.GetOrderByIdAsync(1))
                .ReturnsAsync(
                    new Order());

            var result =
                await _service
                    .GetOrderByIdAsync(1);

            Assert.NotNull(result);
        }

        //CREATE ORDER 

        [Fact]
        public async Task CreateOrderAsync_Should_Return_Order()
        {
            // Fake HTTP response

            var handlerMock =
                new Mock<HttpMessageHandler>();

            handlerMock
               .Protected()
               .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
               .ReturnsAsync(
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.OK
                    });

            var client =
                new HttpClient(handlerMock.Object);

            _httpClientFactoryMock
                .Setup(x =>
                    x.CreateClient(
                        It.IsAny<string>()))
                .Returns(client);

            var dto =
                new OrderDto
                {
                    UserId = 1,
                    CustomerName = "Hemanth",
                    TotalAmount = 1000,
                    Status = "Pending",

                    OrderItems =
                    new List<OrderItemDto>
                    {
                        new OrderItemDto
                        {
                            ProductId = 1,
                            ProductName = "Laptop",
                            Quantity = 1,
                            Price = 1000,
                            TotalAmount = 1000
                        }
                    }
                };

            _repositoryMock
                .Setup(x =>
                    x.CreateOrderAsync(
                        It.IsAny<Order>()))
                .ReturnsAsync(new Order
                {
                    OrderId = 1,
                    OrderDate = DateTime.Now
                });

            var result =
                await _service
                    .CreateOrderAsync(dto);

            Assert.NotNull(result);
        }

        // UPDATE STATUS 

        [Fact]
        public async Task UpdateOrderStatusAsync_Should_Return_True()
        {
            _repositoryMock
                .Setup(x =>
                    x.UpdateOrderStatusAsync(
                        1,
                        "Delivered"))
                .ReturnsAsync(true);

            var result =
                await _service
                    .UpdateOrderStatusAsync(
                        1,
                        "Delivered");

            Assert.True(result);
        }

        // DELETE ORDER 

        [Fact]
        public async Task DeleteOrderAsync_Should_Return_True()
        {
            _repositoryMock
                .Setup(x =>
                    x.DeleteOrderAsync(1))
                .ReturnsAsync(true);

            var result =
                await _service
                    .DeleteOrderAsync(1);

            Assert.True(result);
        }
    }
}