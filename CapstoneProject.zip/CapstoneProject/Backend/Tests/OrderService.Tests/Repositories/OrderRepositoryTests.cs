﻿using Microsoft.EntityFrameworkCore;

using OrderService.Data;
using OrderService.Entities;
using OrderService.Repositories.Implementations;
namespace OrderService.Tests.Repositories
{
    public class OrderRepositoryTests
    {
        private readonly OrderDbContext
            _context;

        private readonly OrderRepository
            _repository;

        public OrderRepositoryTests()
        {
            var options =
                new DbContextOptionsBuilder<OrderDbContext>()
                .UseInMemoryDatabase(
                    Guid.NewGuid().ToString())
                .Options;

            _context =
                new OrderDbContext(options);

            _repository =
                new OrderRepository(_context);
        }

        //  CREATE ORDER 

        [Fact]
        public async Task CreateOrderAsync_Should_Add_Order()
        {
            var order =
                new Order
                {
                    UserId = 1,
                    CustomerName = "Hemanth",
                    TotalPrice = 1000,
                    Status = "Pending",
                    OrderDate = DateTime.Now,

                    Items =
                    new List<OrderItem>()
                };

            var result =
                await _repository
                    .CreateOrderAsync(order);

            Assert.NotNull(result);
        }

        //  GET ALL ORDERS 

        [Fact]
        public async Task GetAllOrdersAsync_Should_Return_Data()
        {
            _context.Orders.Add(
                new Order
                {
                    UserId = 1,
                    CustomerName = "Test",
                    TotalPrice = 1000,
                    Status = "Pending",
                    OrderDate = DateTime.Now,
                    Items = new List<OrderItem>()
                });

            await _context.SaveChangesAsync();

            var result =
                await _repository
                    .GetAllOrdersAsync();

            Assert.NotNull(result);
        }

        // GET ORDER BY ID 

        [Fact]
        public async Task GetOrderByIdAsync_Should_Return_Order()
        {
            _context.Orders.Add(
                new Order
                {
                    OrderId = 1,
                    UserId = 1,
                    CustomerName = "Test",
                    TotalPrice = 1000,
                    Status = "Pending",
                    OrderDate = DateTime.Now,
                    Items = new List<OrderItem>()
                });

            await _context.SaveChangesAsync();

            var result =
                await _repository
                    .GetOrderByIdAsync(1);

            Assert.NotNull(result);
        }

        // UPDATE STATUS 

        [Fact]
        public async Task UpdateOrderStatusAsync_Should_Return_True()
        {
            _context.Orders.Add(
                new Order
                {
                    OrderId = 1,
                    UserId = 1,
                    CustomerName = "Test",
                    TotalPrice = 1000,
                    Status = "Pending",
                    OrderDate = DateTime.Now,
                    Items = new List<OrderItem>()
                });

            await _context.SaveChangesAsync();

            var result =
                await _repository
                    .UpdateOrderStatusAsync(
                        1,
                        "Delivered");

            Assert.True(result);
        }

        //  DELETE ORDER

        [Fact]
        public async Task DeleteOrderAsync_Should_Return_True()
        {
            _context.Orders.Add(
                new Order
                {
                    OrderId = 1,
                    UserId = 1,
                    CustomerName = "Test",
                    TotalPrice = 1000,
                    Status = "Pending",
                    OrderDate = DateTime.Now,
                    Items = new List<OrderItem>()
                });

            await _context.SaveChangesAsync();

            var result =
                await _repository
                    .DeleteOrderAsync(1);

            Assert.True(result);
        }
    }
}