﻿using AuthService.Controllers;
using AuthService.Data;
using AuthService.DTOs;
using AuthService.Entities;
using AuthService.Helpers;

using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

using Moq;

namespace AuthService.Tests.Controllers
{
    public class AuthControllerTests
    {
        private readonly AuthDbContext _context;

        private readonly JwtHelper _jwtHelper;

        private readonly Mock<ILogger<AuthController>> _loggerMock;

        private readonly AuthController _controller;

        public AuthControllerTests()
        {
            // INMEMORY DATABASE 

            var options =
                new DbContextOptionsBuilder<AuthDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            _context = new AuthDbContext(options);

            //  JWT CONFIGURATION 

            var settings = new Dictionary<string, string>
            {
                {"Jwt:Key", "ThisIsMySuperSecretKeyForJwt123456"},
                {"Jwt:Issuer", "TestIssuer"},
                {"Jwt:Audience", "TestAudience"}
            };

            IConfiguration configuration =
                new ConfigurationBuilder()
                .AddInMemoryCollection(settings!)
                .Build();

            _jwtHelper = new JwtHelper(configuration);

            // LOGGER MOCK 

            _loggerMock =
                new Mock<ILogger<AuthController>>();

            // ================= CONTROLLER =================

            _controller =
                new AuthController(
                    _context,
                    _jwtHelper,
                    _loggerMock.Object);
        }

        // REGISTER SUCCESS

        [Fact]
        public async Task Register_Should_Return_Ok()
        {
            // Arrange

            var dto = new RegisterDto
            {
                Name = "Hemanth",
                Email = "hemanth@gmail.com",
                Password = "123"
            };

            // Act

            var result =
                await _controller.Register(dto);

            // Assert

            Assert.IsType<OkObjectResult>(result);
        }

        // REGISTER DUPLICATE 

        [Fact]
        public async Task Register_Should_Return_BadRequest_When_Email_Exists()
        {
            // Arrange

            _context.Users.Add(new User
            {
                UserId = 1,
                Name = "Test",
                Email = "test@gmail.com",
                PasswordHash = "hash",
                Role = "Customer"
            });

            await _context.SaveChangesAsync();

            var dto = new RegisterDto
            {
                Name = "Test",
                Email = "test@gmail.com",
                Password = "123"
            };

            // Act

            var result =
                await _controller.Register(dto);

            // Assert

            Assert.IsType<BadRequestObjectResult>(result);
        }

        //LOGIN SUCCESS 

        [Fact]
        public async Task Login_Should_Return_Ok_When_Valid()
        {
            // Arrange

            var hash =
                BCrypt.Net.BCrypt.HashPassword("123");

            _context.Users.Add(new User
            {
                UserId = 1,
                Name = "Hemanth",
                Email = "hemanth@gmail.com",
                PasswordHash = hash,
                Role = "Customer"
            });

            await _context.SaveChangesAsync();

            var dto = new LoginDto
            {
                Email = "hemanth@gmail.com",
                Password = "123"
            };

            // Act

            var result =
                await _controller.Login(dto);

            // Assert

            Assert.IsType<OkObjectResult>(result);
        }

        // LOGIN INVALID USER 

        [Fact]
        public async Task Login_Should_Return_Unauthorized_When_User_Not_Found()
        {
            // Arrange

            var dto = new LoginDto
            {
                Email = "wrong@gmail.com",
                Password = "123"
            };

            // Act

            var result =
                await _controller.Login(dto);

            // Assert

            Assert.IsType<UnauthorizedObjectResult>(result);
        }

        //LOGIN INVALID PASSWORD 

        [Fact]
        public async Task Login_Should_Return_Unauthorized_When_Password_Invalid()
        {
            // Arrange

            var hash =
                BCrypt.Net.BCrypt.HashPassword("123");

            _context.Users.Add(new User
            {
                UserId = 1,
                Name = "Test",
                Email = "test@gmail.com",
                PasswordHash = hash,
                Role = "Customer"
            });

            await _context.SaveChangesAsync();

            var dto = new LoginDto
            {
                Email = "test@gmail.com",
                Password = "wrong"
            };

            // Act

            var result =
                await _controller.Login(dto);

            // Assert

            Assert.IsType<UnauthorizedObjectResult>(result);
        }

        //  GET USERS 

        [Fact]
        public async Task GetUsers_Should_Return_Ok()
        {
            // Arrange

            _context.Users.Add(new User
            {
                UserId = 1,
                Name = "Admin",
                Email = "admin@gmail.com",
                PasswordHash = "hash",
                Role = "Admin"
            });

            await _context.SaveChangesAsync();

            // Act

            var result =
                await _controller.GetUsers();

            // Assert

            Assert.IsType<OkObjectResult>(result);
        }

        //  UPDATE ROLE SUCCESS 

        [Fact]
        public async Task UpdateRole_Should_Return_Ok()
        {
            // Arrange

            _context.Users.Add(new User
            {
                UserId = 1,
                Name = "User",
                Email = "user@gmail.com",
                PasswordHash = "hash",
                Role = "Customer"
            });

            await _context.SaveChangesAsync();

            var dto = new UpdateRoleDto
            {
                Role = "Admin"
            };

            // Act

            var result =
                await _controller.UpdateRole(1, dto);

            // Assert

            Assert.IsType<OkObjectResult>(result);
        }

        // UPDATE ROLE FAILED

        [Fact]
        public async Task UpdateRole_Should_Return_NotFound()
        {
            // Arrange

            var dto = new UpdateRoleDto
            {
                Role = "Admin"
            };

            // Act

            var result =
                await _controller.UpdateRole(100, dto);

            // Assert

            Assert.IsType<NotFoundObjectResult>(result);
        }
    }
}