﻿using AuthService.DTOs;
using AuthService.Entities;
using AuthService.Helpers;
using AuthService.Repositories.Interfaces;
using AuthService.Services;

using Microsoft.Extensions.Configuration;

using Moq;

namespace AuthService.Tests.Services
{
    public class AuthService1Tests
    {
        private readonly Mock<IUserRepository> _repoMock;

        private readonly JwtHelper _jwtHelper;

        private readonly AuthService1 _service;

        public AuthService1Tests()
        {
            // MOCK REPOSITORY 

            _repoMock =
                new Mock<IUserRepository>();

            // JWT CONFIGURATION 

            var settings = new Dictionary<string, string>
            {
                 {"Jwt:Key", "ThisIsMySuperSecretKeyForJwt123456"},
                {"Jwt:Issuer", "TestIssuer"},
                {"Jwt:Audience", "TestAudience"}
            };

            IConfiguration configuration =
                new ConfigurationBuilder()
                .AddInMemoryCollection(settings!)
                .Build();

            _jwtHelper =
                new JwtHelper(configuration);

            //  SERVICE 

            _service =
                new AuthService1(
                    _repoMock.Object,
                    _jwtHelper);
        }

        // REGISTER SUCCESS

        [Fact]
        public async Task RegisterAsync_Should_Return_Token()
        {
            // Arrange

            var dto = new RegisterDto
            {
                Name = "Hemanth",
                Email = "hemanth@gmail.com",
                Password = "123"
            };

            _repoMock
                .Setup(x =>
                    x.GetByEmailAsync(dto.Email))
                .ReturnsAsync((User?)null);

            // Act

            var result =
                await _service.RegisterAsync(dto);

            // Assert

            Assert.NotNull(result);
        }

        // REGISTER FAILED 

        [Fact]
        public async Task RegisterAsync_Should_Throw_Exception_When_User_Exists()
        {
            // Arrange

            var dto = new RegisterDto
            {
                Name = "Test",
                Email = "test@gmail.com",
                Password = "123"
            };

            _repoMock
                .Setup(x =>
                    x.GetByEmailAsync(dto.Email))
                .ReturnsAsync(new User
                {
                    UserId = 1,
                    Name = "Existing User",
                    Email = dto.Email,
                    PasswordHash = "hash",
                    Role = "Customer"
                });

            // Act & Assert

            await Assert.ThrowsAsync<Exception>(
                () => _service.RegisterAsync(dto));
        }

        // LOGIN SUCCESS

        [Fact]
        public async Task LoginAsync_Should_Return_Token()
        {
            // Arrange

            var hash =
                BCrypt.Net.BCrypt.HashPassword("123");

            var dto = new LoginDto
            {
                Email = "test@gmail.com",
                Password = "123"
            };

            _repoMock
                .Setup(x =>
                    x.GetByEmailAsync(dto.Email))
                .ReturnsAsync(new User
                {
                    UserId = 1,
                    Name = "Test",
                    Email = dto.Email,
                    PasswordHash = hash,
                    Role = "Customer"
                });

            // Act

            var result =
                await _service.LoginAsync(dto);

            // Assert

            Assert.NotNull(result);
        }

        // LOGIN FAILED 

        [Fact]
        public async Task LoginAsync_Should_Throw_Exception_When_Invalid_User()
        {
            // Arrange

            var dto = new LoginDto
            {
                Email = "wrong@gmail.com",
                Password = "123"
            };

            _repoMock
                .Setup(x =>
                    x.GetByEmailAsync(dto.Email))
                .ReturnsAsync((User?)null);

            // Act & Assert

            await Assert.ThrowsAsync<Exception>(
                () => _service.LoginAsync(dto));
        }

        // LOGIN INVALID PASSWORD 

        [Fact]
        public async Task LoginAsync_Should_Throw_Exception_When_Invalid_Password()
        {
            // Arrange

            var hash =
                BCrypt.Net.BCrypt.HashPassword("123");

            var dto = new LoginDto
            {
                Email = "test@gmail.com",
                Password = "wrongpassword"
            };

            _repoMock
                .Setup(x =>
                    x.GetByEmailAsync(dto.Email))
                .ReturnsAsync(new User
                {
                    UserId = 1,
                    Name = "Test",
                    Email = dto.Email,
                    PasswordHash = hash,
                    Role = "Customer"
                });

            // Act & Assert

            await Assert.ThrowsAsync<Exception>(
                () => _service.LoginAsync(dto));
        }
    }
}