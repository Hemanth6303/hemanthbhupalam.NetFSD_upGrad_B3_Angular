﻿using AuthService.Data;
using AuthService.Entities;
using AuthService.Repositories;

using Microsoft.EntityFrameworkCore;

namespace AuthService.Tests.Repositories
{
    public class UserRepositoryTests
    {
        private readonly AuthDbContext _context;

        private readonly UserRepository _repository;

        public UserRepositoryTests()
        {
            var options =
                new DbContextOptionsBuilder<AuthDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            _context =
                new AuthDbContext(options);

            _repository =
                new UserRepository(_context);
        }

        //  ADD USER 

        [Fact]
        public async Task AddAsync_Should_Add_User()
        {
            var user = new User
            {
                Name = "Hemanth",
                Email = "hemanth@gmail.com",
                PasswordHash = "hash"
            };

            await _repository.AddAsync(user);

            var result =
                await _context.Users
                .FirstOrDefaultAsync(
                    x => x.Email == user.Email);

            Assert.NotNull(result);
        }

        //  GET USER 

        [Fact]
        public async Task GetByEmailAsync_Should_Return_User()
        {
            _context.Users.Add(new User
            {
                Name = "Test",
                Email = "test@gmail.com",
                PasswordHash = "hash"
            });

            await _context.SaveChangesAsync();

            var result =
                await _repository
                .GetByEmailAsync("test@gmail.com");

            Assert.NotNull(result);
        }

        //  GET USER FAILED 

        [Fact]
        public async Task GetByEmailAsync_Should_Return_Null_When_Not_Exists()
        {
            var result =
                await _repository
                .GetByEmailAsync("wrong@gmail.com");

            Assert.Null(result);
        }
    }
}