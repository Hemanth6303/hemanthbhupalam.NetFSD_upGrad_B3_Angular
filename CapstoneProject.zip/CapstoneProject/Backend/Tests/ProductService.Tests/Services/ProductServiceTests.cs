﻿using Moq;

using ProductService.DTOs;
using ProductService.Repositories.Interfaces;
using ProductService.Services.Implementations;

namespace ProductService.Tests.Services
{
    public class ProductServiceTests
    {
        private readonly Mock<IProductRepository>
            _repositoryMock;

        private readonly ProductService.Services.Implementations.ProductService
            _service;

        public ProductServiceTests()
        {
            _repositoryMock =
                new Mock<IProductRepository>();

            _service =
                new ProductService.Services.Implementations.ProductService(
                    _repositoryMock.Object);
        }

        // GET PRODUCTS 

        [Fact]
        public async Task GetProductsAsync_Should_Return_Data()
        {
            var response =
                new PaginationResponseDto<ProductDto>
                {
                    Items = new List<ProductDto>()
                };

            _repositoryMock
                .Setup(x =>
                    x.GetProductsAsync("", 1, 10))
                .ReturnsAsync(response);

            var result =
                await _service.GetProductsAsync("", 1, 10);

            Assert.NotNull(result);
        }

        //  GET BY ID 

        [Fact]
        public async Task GetByIdAsync_Should_Return_Product()
        {
            _repositoryMock
                .Setup(x =>
                    x.GetByIdAsync(1))
                .ReturnsAsync(new ProductDto());

            var result =
                await _service.GetByIdAsync(1);

            Assert.NotNull(result);
        }

        //  ADD 

        [Fact]
        public async Task AddAsync_Should_Return_Product()
        {
            var dto =
                new ProductDto
                {
                    ProductId = 1,
                    Name = "Laptop"
                };

            _repositoryMock
                .Setup(x =>
                    x.AddAsync(dto))
                .ReturnsAsync(dto);

            var result =
                await _service.AddAsync(dto);

            Assert.NotNull(result);
        }

        // UPDATE 

        [Fact]
        public async Task UpdateAsync_Should_Return_True()
        {
            _repositoryMock
                .Setup(x =>
                    x.UpdateAsync(
                        It.IsAny<ProductDto>()))
                .ReturnsAsync(true);

            var result =
                await _service.UpdateAsync(
                    new ProductDto());

            Assert.True(result);
        }

        //  DELETE 

        [Fact]
        public async Task DeleteAsync_Should_Return_True()
        {
            _repositoryMock
                .Setup(x =>
                    x.DeleteAsync(1))
                .ReturnsAsync(true);

            var result =
                await _service.DeleteAsync(1);

            Assert.True(result);
        }

        // REDUCE STOCK 

        [Fact]
        public async Task ReduceStockAsync_Should_Return_True()
        {
            _repositoryMock
                .Setup(x =>
                    x.ReduceStockAsync(1, 2))
                .ReturnsAsync(true);

            var result =
                await _service.ReduceStockAsync(1, 2);

            Assert.True(result);
        }
    }
}