﻿using Xunit;

namespace ProductService.Tests.Repositories
{
    public class ProductRepositoryTests
    {
        [Fact]
        public void Repository_Test()
        {
            Assert.True(true);
        }
    }
}