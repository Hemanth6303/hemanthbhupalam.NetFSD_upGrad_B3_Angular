﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using Moq;

using ProductService.Controllers;
using ProductService.DTOs;
using ProductService.Services.Interfaces;

namespace ProductService.Tests.Controllers
{
    public class ProductsControllerTests
    {
        private readonly Mock<IProductService>
            _serviceMock;

        private readonly Mock<ILogger<ProductsController>>
            _loggerMock;

        private readonly ProductsController
            _controller;

        public ProductsControllerTests()
        {
            _serviceMock =
                new Mock<IProductService>();

            _loggerMock =
                new Mock<ILogger<ProductsController>>();

            _controller =
                new ProductsController(
                    _serviceMock.Object,
                    _loggerMock.Object);

            _controller.ControllerContext =
                new ControllerContext
                {
                    HttpContext =
                        new DefaultHttpContext()
                };
        }

        // GET PRODUCTS 

        [Fact]
        public async Task GetProducts_Should_Return_Ok()
        {
            var response =
                new PaginationResponseDto<ProductDto>
                {
                    Items = new List<ProductDto>()
                };

            _serviceMock
                .Setup(x =>
                    x.GetProductsAsync("", 1, 10))
                .ReturnsAsync(response);

            var result =
                await _controller.GetProducts();

            Assert.IsType<OkObjectResult>(result);
        }

        // GET BY ID SUCCESS 

        [Fact]
        public async Task GetById_Should_Return_Ok()
        {
            var product =
                new ProductDto
                {
                    ProductId = 1,
                    Name = "Laptop"
                };

            _serviceMock
                .Setup(x =>
                    x.GetByIdAsync(1))
                .ReturnsAsync(product);

            var result =
                await _controller.GetById(1);

            Assert.IsType<OkObjectResult>(result);
        }

        // GET BY ID FAILED 

        [Fact]
        public async Task GetById_Should_Return_NotFound()
        {
            _serviceMock
                .Setup(x =>
                    x.GetByIdAsync(1))
                .ReturnsAsync((ProductDto?)null);

            var result =
                await _controller.GetById(1);

            Assert.IsType<NotFoundObjectResult>(result);
        }

        //  CREATE 

        [Fact]
        public async Task Create_Should_Return_Ok()
        {
            var dto =
                new ProductDto
                {
                    ProductId = 1,
                    Name = "Laptop"
                };

            _serviceMock
                .Setup(x =>
                    x.AddAsync(dto))
                .ReturnsAsync(dto);

            var result =
                await _controller.Create(dto);

            Assert.IsType<OkObjectResult>(result);
        }

        //UPDATE SUCCESS 

        [Fact]
        public async Task Update_Should_Return_Ok()
        {
            var dto =
                new ProductDto
                {
                    ProductId = 1,
                    Name = "Laptop"
                };

            _serviceMock
                .Setup(x =>
                    x.UpdateAsync(
                        It.IsAny<ProductDto>()))
                .ReturnsAsync(true);

            var result =
                await _controller.Update(1, dto);

            Assert.IsType<OkObjectResult>(result);
        }

        //UPDATE FAILED

        [Fact]
        public async Task Update_Should_Return_NotFound()
        {
            var dto =
                new ProductDto();

            _serviceMock
                .Setup(x =>
                    x.UpdateAsync(
                        It.IsAny<ProductDto>()))
                .ReturnsAsync(false);

            var result =
                await _controller.Update(1, dto);

            Assert.IsType<NotFoundObjectResult>(result);
        }

        // DELETE SUCCESS 

        [Fact]
        public async Task Delete_Should_Return_Ok()
        {
            _serviceMock
                .Setup(x =>
                    x.DeleteAsync(1))
                .ReturnsAsync(true);

            var result =
                await _controller.Delete(1);

            Assert.IsType<OkObjectResult>(result);
        }

        //  DELETE FAILED 

        [Fact]
        public async Task Delete_Should_Return_NotFound()
        {
            _serviceMock
                .Setup(x =>
                    x.DeleteAsync(1))
                .ReturnsAsync(false);

            var result =
                await _controller.Delete(1);

            Assert.IsType<NotFoundObjectResult>(result);
        }

        // REDUCE STOCK SUCCESS 

        [Fact]
        public async Task ReduceStock_Should_Return_Ok()
        {
            _serviceMock
                .Setup(x =>
                    x.ReduceStockAsync(1, 2))
                .ReturnsAsync(true);

            var result =
                await _controller.ReduceStock(1, 2);

            Assert.IsType<OkObjectResult>(result);
        }

        // REDUCE STOCK FAILED 

        [Fact]
        public async Task ReduceStock_Should_Return_BadRequest()
        {
            _serviceMock
                .Setup(x =>
                    x.ReduceStockAsync(1, 2))
                .ReturnsAsync(false);

            var result =
                await _controller.ReduceStock(1, 2);

            Assert.IsType<BadRequestObjectResult>(result);
        }
    }
}