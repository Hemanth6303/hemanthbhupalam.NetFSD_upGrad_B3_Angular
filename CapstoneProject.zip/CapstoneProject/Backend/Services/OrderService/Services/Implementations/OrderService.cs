﻿using System.Net.Http;
using OrderService.DTOs;
using OrderService.Entities;
using OrderService.Repositories.Interfaces;
using OrderService.Services.Interfaces;

namespace OrderService.Services.Implementations;

public class OrderService
    : IOrderService
{
    private readonly IOrderRepository
        _repository;

    private readonly IHttpClientFactory
        _httpClientFactory;

    public OrderService(
        IOrderRepository repository,
        IHttpClientFactory httpClientFactory)
    {
        _repository = repository;

        _httpClientFactory =
            httpClientFactory;
    }

    // GET ALL ORDERS 

    public async Task<IEnumerable<OrderDto>>
        GetAllOrdersAsync()
    {
        var orders =
            await _repository.GetAllOrdersAsync();

        return orders.Select(order =>
            new OrderDto
            {
                OrderId = order.OrderId,

                UserId = order.UserId,

                CustomerName =
                    order.CustomerName,

                TotalAmount =
                    order.TotalPrice,

                OrderDate =
                    order.OrderDate,

                Status =
                    order.Status,

                OrderItems =
                    order.Items.Select(item =>
                        new OrderItemDto
                        {
                            OrderItemId =
                                item.OrderItemId,

                            ProductId =
                                item.ProductId,

                            ProductName =
                                item.ProductName,

                            Quantity =
                                item.Quantity,

                            Price =
                                item.Price,

                            TotalAmount =
                                item.TotalAmount
                        }).ToList()
            });
    }

    // GET ORDERS BY USER 

    public async Task<IEnumerable<OrderDto>>
        GetOrdersByUserIdAsync(int userId)
    {
        var orders =
            await _repository
            .GetOrdersByUserIdAsync(userId);

        return orders.Select(order =>
            new OrderDto
            {
                OrderId = order.OrderId,

                UserId = order.UserId,

                CustomerName =
                    order.CustomerName,

                TotalAmount =
                    order.TotalPrice,

                OrderDate =
                    order.OrderDate,

                Status =
                    order.Status,

                OrderItems =
                    order.Items.Select(item =>
                        new OrderItemDto
                        {
                            OrderItemId =
                                item.OrderItemId,

                            ProductId =
                                item.ProductId,

                            ProductName =
                                item.ProductName,

                            Quantity =
                                item.Quantity,

                            Price =
                                item.Price,

                            TotalAmount =
                                item.TotalAmount
                        }).ToList()
            });
    }

    // GET ORDER BY ID 

    public async Task<OrderDto?>
        GetOrderByIdAsync(int orderId)
    {
        var order =
            await _repository
            .GetOrderByIdAsync(orderId);

        if (order == null)
        {
            return null;
        }

        return new OrderDto
        {
            OrderId = order.OrderId,

            UserId = order.UserId,

            CustomerName =
                order.CustomerName,

            TotalAmount =
                order.TotalPrice,

            OrderDate =
                order.OrderDate,

            Status =
                order.Status,

            OrderItems =
                order.Items.Select(item =>
                    new OrderItemDto
                    {
                        OrderItemId =
                            item.OrderItemId,

                        ProductId =
                            item.ProductId,

                        ProductName =
                            item.ProductName,

                        Quantity =
                            item.Quantity,

                        Price =
                            item.Price,

                        TotalAmount =
                            item.TotalAmount
                    }).ToList()
        };
    }

    // CREATE ORDER 

    public async Task<OrderDto>
        CreateOrderAsync(OrderDto dto)
    {
        //  STOCK VALIDATION 

        var client =
            _httpClientFactory.CreateClient();

        foreach (var item in dto.OrderItems)
        {
            var response =
                await client.PutAsync(
                    $"https://localhost:7141/api/products/{item.ProductId}/reduce-stock?quantity={item.Quantity}",
                    null);

            if (!response.IsSuccessStatusCode)
            {
                throw new ApplicationException(
                    $"Insufficient stock for product id {item.ProductId}");
            }
        }

        // CREATE ORDER 

        var order = new Order
        {
            UserId = dto.UserId,

            CustomerName =
                dto.CustomerName,

            TotalPrice =
                dto.TotalAmount,

            OrderDate =
                DateTime.Now,

            Status =
                dto.Status,

            Items =
                dto.OrderItems.Select(item =>
                    new OrderItem
                    {
                        ProductId =
                            item.ProductId,

                        ProductName =
                            item.ProductName,

                        Quantity =
                            item.Quantity,

                        Price =
                            item.Price,

                        TotalAmount =
                            item.TotalAmount
                    }).ToList()
        };

        var createdOrder =
            await _repository
            .CreateOrderAsync(order);

        dto.OrderId =
            createdOrder.OrderId;

        dto.OrderDate =
            createdOrder.OrderDate;

        return dto;
    }

    // UPDATE ORDER STATUS 

    public async Task<bool>
        UpdateOrderStatusAsync(
            int orderId,
            string status)
    {
        return await _repository
            .UpdateOrderStatusAsync(
                orderId,
                status);
    }

    // DELETE ORDER 

    public async Task<bool>
        DeleteOrderAsync(int orderId)
    {
        return await _repository
            .DeleteOrderAsync(orderId);
    }
}