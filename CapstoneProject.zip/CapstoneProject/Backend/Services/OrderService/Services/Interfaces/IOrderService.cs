﻿using OrderService.DTOs;

namespace OrderService.Services.Interfaces;

public interface IOrderService
{

    Task<IEnumerable<OrderDto>>
    GetAllOrdersAsync();

    Task<IEnumerable<OrderDto>>
        GetOrdersByUserIdAsync(int userId);

    Task<OrderDto?>
        GetOrderByIdAsync(int orderId);

    Task<OrderDto>
        CreateOrderAsync(OrderDto dto);

    Task<bool>
        UpdateOrderStatusAsync(
            int orderId,
            string status);

    Task<bool>
        DeleteOrderAsync(int orderId);
}