﻿namespace OrderService.Entities;

public class Order
{
    public int OrderId { get; set; }

    public int UserId { get; set; }

    public string CustomerName { get; set; }
        = string.Empty;

    public decimal TotalPrice { get; set; }

    public DateTime OrderDate { get; set; }

    public string Status { get; set; }
        = string.Empty;

    public ICollection<OrderItem> Items
    { get; set; } = new List<OrderItem>();
}