﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using OrderService.DTOs;
using OrderService.Services.Interfaces;

namespace OrderService.Controllers;

// Controller for order management operations

[ApiController]
[Route("api/orders")]
public class OrdersController : ControllerBase
{
    // Order service object

    private readonly IOrderService _service;

    // Logger object

    private readonly ILogger<OrdersController>
        _logger;

    // Constructor injection

    public OrdersController(
        IOrderService service,
        ILogger<OrdersController> logger)
    {
        _service = service;

        _logger = logger;
    }

    // GET ALL ORDERS 
    // Returns all orders for admin

    [Authorize(Roles = "Admin")]
    [HttpGet]
    public async Task<IActionResult>
        GetAllOrders()
    {
        // Fetch all orders

        var orders =
            await _service.GetAllOrdersAsync();

        // Return orders list

        return Ok(orders);
    }

    // GET USER ORDERS 
    // Returns orders using user id

    [Authorize]
    [HttpGet("user/{userId}")]
    public async Task<IActionResult>
        GetOrdersByUserId(int userId)
    {
        // Log information

        _logger.LogInformation(
            "Getting user orders");

        // Fetch user orders

        var orders =
            await _service
            .GetOrdersByUserIdAsync(userId);

        // Return user orders

        return Ok(orders);
    }

    //  GET ORDER BY ID 
    // Returns order details using order id

    [Authorize]
    [HttpGet("{orderId}")]
    public async Task<IActionResult>
        GetOrderById(int orderId)
    {
        // Log information

        _logger.LogInformation(
            "Getting order by id");

        // Fetch order details

        var order =
            await _service
            .GetOrderByIdAsync(orderId);

        // Check if order exists

        if (order == null)
        {
            return NotFound(new
            {
                message = "Order not found"
            });
        }

        // Return order details

        return Ok(order);
    }

    // CREATE ORDER 
    // Creates new order

    [Authorize]
    [HttpPost]
    public async Task<IActionResult>
        CreateOrder(OrderDto dto)
    {
        // Log information

        _logger.LogInformation(
            "Creating order");

        // Create order

        var order =
            await _service
            .CreateOrderAsync(dto);

        // Return created order

        return Ok(order);
    }

    // UPDATE ORDER STATUS 
    // Updates order status

    [Authorize(Roles = "Admin")]
    [HttpPut("{orderId}/status")]
    public async Task<IActionResult>
        UpdateOrderStatus(
            int orderId,
            [FromBody] string status)
    {
        // Log information

        _logger.LogInformation(
            "Updating order status");

        // Update status

        var updated =
            await _service
            .UpdateOrderStatusAsync(
                orderId,
                status);

        // Check if order exists

        if (!updated)
        {
            return NotFound(new
            {
                message = "Order not found"
            });
        }

        // Return success response

        return Ok(new
        {
            message =
                "Order status updated successfully"
        });
    }

    //  DELETE ORDER 
    // Deletes order using order id

    [Authorize]
    [HttpDelete("{orderId}")]
    public async Task<IActionResult>
        DeleteOrder(int orderId)
    {
        // Log information

        _logger.LogInformation(
            "Deleting order");

        // Delete order

        var deleted =
            await _service
            .DeleteOrderAsync(orderId);

        // Check if order exists

        if (!deleted)
        {
            return NotFound(new
            {
                message = "Order not found"
            });
        }

        // Return success response

        return Ok(new
        {
            message =
                "Order deleted successfully"
        });
    }
}