﻿using Microsoft.EntityFrameworkCore;
using OrderService.Data;
using OrderService.Entities;
using OrderService.Repositories.Interfaces;

namespace OrderService.Repositories.Implementations;

public class OrderRepository
    : IOrderRepository
{
    private readonly OrderDbContext _context;

    public OrderRepository(
        OrderDbContext context)
    {
        _context = context;
    }

    // Get all orders

    public async Task<IEnumerable<Order>>
        GetAllOrdersAsync()
    {
        return await _context.Orders
            .Include(x => x.Items)
            .OrderByDescending(x => x.OrderDate)
            .ToListAsync();
    }

    // Get orders by user id

    public async Task<IEnumerable<Order>>
        GetOrdersByUserIdAsync(int userId)
    {
        return await _context.Orders
            .Include(x => x.Items)
            .Where(x => x.UserId == userId)
            .OrderByDescending(x => x.OrderDate)
            .ToListAsync();
    }

    // Get order by id

    public async Task<Order?>
        GetOrderByIdAsync(int orderId)
    {
        return await _context.Orders
            .Include(x => x.Items)
            .FirstOrDefaultAsync(
                x => x.OrderId == orderId);
    }

    // Create order

    public async Task<Order>
        CreateOrderAsync(Order order)
    {
        _context.Orders.Add(order);

        await _context.SaveChangesAsync();

        return order;
    }

    // Update order status

    public async Task<bool>
        UpdateOrderStatusAsync(
            int orderId,
            string status)
    {
        var order =
            await _context.Orders
            .FirstOrDefaultAsync(
                x => x.OrderId == orderId);

        if (order == null)
        {
            return false;
        }

        order.Status = status;

        await _context.SaveChangesAsync();

        return true;
    }

    // Delete order

    public async Task<bool>
        DeleteOrderAsync(int orderId)
    {
        var order =
            await _context.Orders
            .Include(x => x.Items)
            .FirstOrDefaultAsync(
                x => x.OrderId == orderId);

        if (order == null)
        {
            return false;
        }

        _context.OrderItems.RemoveRange(
            order.Items);

        _context.Orders.Remove(order);

        await _context.SaveChangesAsync();

        return true;
    }
}