﻿using OrderService.Entities;

namespace OrderService.Repositories.Interfaces;

public interface IOrderRepository
{

    Task<IEnumerable<Order>>
    GetAllOrdersAsync();

    Task<IEnumerable<Order>>
        GetOrdersByUserIdAsync(int userId);

    Task<Order?>
        GetOrderByIdAsync(int orderId);

    Task<Order>
        CreateOrderAsync(Order order);

    Task<bool>
        UpdateOrderStatusAsync(
            int orderId,
            string status);

    Task<bool>
        DeleteOrderAsync(int orderId);
}