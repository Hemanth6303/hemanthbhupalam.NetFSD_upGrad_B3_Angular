﻿using Microsoft.EntityFrameworkCore;
using OrderService.Entities;

namespace OrderService.Data;

// Database context class for Order Service

public class OrderDbContext : DbContext
{
    // Constructor injection

    public OrderDbContext(
        DbContextOptions<OrderDbContext> options)
        : base(options)
    {
    }

    // ORDERS TABLE 
    // Represents Orders table in database

    public DbSet<Order> Orders => Set<Order>();

    // ORDER ITEMS TABLE 
    // Represents OrderItems table in database

    public DbSet<OrderItem> OrderItems
        => Set<OrderItem>();

    // ENTITY RELATIONSHIPS 
    // Configure table relationships

    protected override void OnModelCreating(
        ModelBuilder modelBuilder)
    {
        // One Order can have many OrderItems

        modelBuilder.Entity<Order>()
            .HasMany(x => x.Items)

            // Each OrderItem belongs to one Order

            .WithOne(x => x.Order)

            // Foreign key in OrderItems table

            .HasForeignKey(x => x.OrderId);
    }
}