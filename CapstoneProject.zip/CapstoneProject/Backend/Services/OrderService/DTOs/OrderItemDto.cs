﻿
using System.ComponentModel.DataAnnotations;

namespace OrderService.DTOs;

public class OrderItemDto
{
    public int OrderItemId { get; set; }

    [Required(ErrorMessage = "Product Id is required")]
    public int ProductId { get; set; }

    [Required(ErrorMessage = "Product name is required")]
    [MinLength(2, ErrorMessage = "Product name must be at least 2 characters")]
    public string ProductName { get; set; }
        = string.Empty;

    [Range(1, 100,
        ErrorMessage = "Quantity must be greater than 0")]
    public int Quantity { get; set; }

    [Range(1, 1000000,
        ErrorMessage = "Price must be greater than 0")]
    public decimal Price { get; set; }

    [Range(1, 1000000,
        ErrorMessage = "Total amount must be greater than 0")]
    public decimal TotalAmount { get; set; }
}