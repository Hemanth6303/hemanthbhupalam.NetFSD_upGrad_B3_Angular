﻿using System.ComponentModel.DataAnnotations;

namespace OrderService.DTOs;

public class OrderDto
{
    public int OrderId { get; set; }

    [Required(ErrorMessage = "User Id is required")]
    public int UserId { get; set; }

    [Required(ErrorMessage = "Customer name is required")]
    [MinLength(3, ErrorMessage = "Customer name must be at least 3 characters")]
    public string CustomerName { get; set; }
        = string.Empty;

    [Range(1, 1000000,
        ErrorMessage = "Total amount must be greater than 0")]
    public decimal TotalAmount { get; set; }

    public DateTime OrderDate { get; set; }

    [Required(ErrorMessage = "Order status is required")]
    public string Status { get; set; }
        = string.Empty;

    [Required(ErrorMessage = "Order items are required")]
    [MinLength(1, ErrorMessage = "At least one order item is required")]
    public List<OrderItemDto> OrderItems
    { get; set; } = new();
}