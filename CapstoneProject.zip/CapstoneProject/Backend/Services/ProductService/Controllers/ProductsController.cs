﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProductService.DTOs;
using ProductService.Services.Interfaces;

namespace ProductService.Controllers;

[ApiController]
[Route("api/products")]
public class ProductsController
    : ControllerBase
{
    private readonly IProductService _service;

    private readonly ILogger<ProductsController>
        _logger;

    public ProductsController(
        IProductService service,
        ILogger<ProductsController> logger)
    {
        _service = service;

        _logger = logger;
    }

    // Get products with search and pagination
    [HttpGet]
    public async Task<IActionResult>
 GetProducts(
     string? search = "",
     int page = 1,
     int pageSize = 10)
    {
        var result =
            await _service.GetProductsAsync(
                search,
                page,
                pageSize);

        // If request contains pagination/search
        // return paged object

        if (Request.Query.ContainsKey("page")
            || Request.Query.ContainsKey("search")
            || Request.Query.ContainsKey("pageSize"))
        {
            return Ok(result);
        }

        // Normal getAll()

        return Ok(result.Items);
    }
    // Get product by id

    [HttpGet("{id}")]
    public async Task<IActionResult>
        GetById(int id)
    {
        var product =
            await _service.GetByIdAsync(id);

        if (product == null)
        {
            return NotFound(new
            {
                message = "Product not found"
            });
        }

        return Ok(product);
    }

    // Add product

    [Authorize(Roles = "Admin")]
    [HttpPost]
    public async Task<IActionResult>
        Create(ProductDto dto)
    {
        var product =
            await _service.AddAsync(dto);

        return Ok(product);
    }

    // Update product

    [Authorize(Roles = "Admin")]
    [HttpPut("{id}")]
    public async Task<IActionResult>
        Update(
            int id,
            ProductDto dto)
    {
        dto.ProductId = id;

        var updated =
            await _service.UpdateAsync(dto);

        if (!updated)
        {
            return NotFound(new
            {
                message = "Product not found"
            });
        }

        return Ok(new
        {
            message =
                "Product updated successfully"
        });
    }

    // Delete product

    [Authorize(Roles = "Admin")]
    [HttpDelete("{id}")]
    public async Task<IActionResult>
        Delete(int id)
    {
        var deleted =
            await _service.DeleteAsync(id);

        if (!deleted)
        {
            return NotFound(new
            {
                message = "Product not found"
            });
        }

        return Ok(new
        {
            message =
                "Product deleted successfully"
        });
    }

    
    [HttpPut("{id}/reduce-stock")]
    public async Task<IActionResult>
ReduceStock(
    int id,
    [FromQuery] int quantity)
    {
        var result =
            await _service.ReduceStockAsync(
                id,
                quantity);

        if (!result)
        {
            return BadRequest(new
            {
                message =
                    "Insufficient stock"
            });
        }

        return Ok(new
        {
            message =
                "Stock updated successfully"
        });
    }
}