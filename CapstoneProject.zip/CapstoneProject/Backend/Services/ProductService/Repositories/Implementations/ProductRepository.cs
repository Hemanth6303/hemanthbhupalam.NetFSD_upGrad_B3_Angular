﻿using Dapper;

using Microsoft.Data.SqlClient;

using ProductService.DTOs;

using ProductService.Repositories.Interfaces;

namespace ProductService.Repositories.Implementations;

public class ProductRepository
    : IProductRepository
{
    private readonly IConfiguration _configuration;

    public ProductRepository(
        IConfiguration configuration)
    {
        _configuration = configuration;
    }

    //  DATABASE CONNECTION 

    private SqlConnection CreateConnection()
    {
        return new SqlConnection(
            _configuration
            .GetConnectionString(
                "DefaultConnection"));
    }

    // GET PRODUCTS 

    public async Task<
        PaginationResponseDto<ProductDto>>
        GetProductsAsync(
            string? search,
            int pageNumber,
            int pageSize)
    {
        using var connection =
            CreateConnection();

        var whereClause = "";

        if (!string.IsNullOrEmpty(search))
        {
            whereClause = @"
                WHERE
                    Name LIKE @Search
                    OR
                    CategoryName LIKE @Search";
        }

        //  TOTAL RECORDS 

        var countQuery = $@"
            SELECT COUNT(*)
            FROM Products
            {whereClause}";

        var totalRecords =
            await connection.ExecuteScalarAsync<int>(
                countQuery,
                new
                {
                    Search = $"%{search}%"
                });

        // PRODUCT QUERY 

        var query = $@"
            SELECT
                ProductId,
                Name,
                Description,
                Price,
                ImageUrl,
                Stock,
                CategoryName

            FROM Products

            {whereClause}

            ORDER BY ProductId

            OFFSET @Offset ROWS
            FETCH NEXT @PageSize ROWS ONLY";

        var products =
            await connection.QueryAsync<ProductDto>(
                query,
                new
                {
                    Search = $"%{search}%",

                    Offset =
                        (pageNumber - 1) * pageSize,

                    PageSize = pageSize
                });

        return new PaginationResponseDto<ProductDto>
        {
            Items = products,

            TotalRecords = totalRecords,

            PageNumber = pageNumber,

            PageSize = pageSize,

            TotalPages =
                (int)Math.Ceiling(
                    totalRecords /
                    (double)pageSize)
        };
    }

    // GET PRODUCT BY ID 

    public async Task<ProductDto?>
        GetByIdAsync(int id)
    {
        var query = @"
            SELECT
                ProductId,
                Name,
                Description,
                Price,
                ImageUrl,
                Stock,
                CategoryName

            FROM Products

            WHERE ProductId = @Id";

        using var connection =
            CreateConnection();

        return await connection
            .QueryFirstOrDefaultAsync<ProductDto>(
                query,
                new { Id = id });
    }

    // ADD PRODUCT 

    public async Task<ProductDto>
        AddAsync(ProductDto dto)
    {
        using var connection =
            CreateConnection();

        // INSERT PRODUCT 

        var insertQuery = @"
            INSERT INTO Products
            (
                Name,
                Description,
                Price,
                ImageUrl,
                Stock,
                CategoryName
            )
            VALUES
            (
                @Name,
                @Description,
                @Price,
                @ImageUrl,
                @Stock,
                @CategoryName
            );

            SELECT CAST(
                SCOPE_IDENTITY()
                AS INT)";

        var productId =
            await connection
            .ExecuteScalarAsync<int>(
                insertQuery,
                dto);

        // FETCH INSERTED PRODUCT

        var selectQuery = @"
            SELECT
                ProductId,
                Name,
                Description,
                Price,
                ImageUrl,
                Stock,
                CategoryName

            FROM Products

            WHERE ProductId = @ProductId";

        return await connection
            .QueryFirstOrDefaultAsync<ProductDto>(
                selectQuery,
                new
                {
                    ProductId = productId
                });
    }

    // UPDATE PRODUCT 

    public async Task<bool>
        UpdateAsync(ProductDto dto)
    {
        using var connection =
            CreateConnection();

        var query = @"
            UPDATE Products
            SET
                Name = @Name,
                Description = @Description,
                Price = @Price,
                ImageUrl = @ImageUrl,
                Stock = @Stock,
                CategoryName = @CategoryName
            WHERE ProductId = @ProductId";

        var rowsAffected =
            await connection.ExecuteAsync(
                query,
                dto);

        return rowsAffected > 0;
    }

    //DELETE PRODUCT 

    public async Task<bool>
        DeleteAsync(int id)
    {
        var query = @"
            DELETE FROM Products
            WHERE ProductId = @Id";

        using var connection =
            CreateConnection();

        var rowsAffected =
            await connection.ExecuteAsync(
                query,
                new { Id = id });

        return rowsAffected > 0;
    }

    // REDUCE STOCK 

    public async Task<bool>
        ReduceStockAsync(
            int productId,
            int quantity)
    {
        using var connection =
            CreateConnection();

        // GET CURRENT STOCK 

        var stockQuery = @"
            SELECT Stock
            FROM Products
            WHERE ProductId = @ProductId";

        var currentStock =
            await connection
            .ExecuteScalarAsync<int?>(
                stockQuery,
                new
                {
                    ProductId = productId
                });

        // Product not found

        if (currentStock == null)
        {
            return false;
        }

        // Insufficient stock

        if (currentStock < quantity)
        {
            return false;
        }

        var updatedStock =
            currentStock.Value - quantity;

        // DELETE PRODUCT 

        if (updatedStock == 0)
        {
            var deleteQuery = @"
                DELETE FROM Products
                WHERE ProductId = @ProductId";

            await connection.ExecuteAsync(
                deleteQuery,
                new
                {
                    ProductId = productId
                });

            return true;
        }

        // UPDATE STOCK 

        var updateQuery = @"
            UPDATE Products
            SET Stock = @Stock
            WHERE ProductId = @ProductId";

        await connection.ExecuteAsync(
            updateQuery,
            new
            {
                ProductId = productId,
                Stock = updatedStock
            });

        return true;
    }
}