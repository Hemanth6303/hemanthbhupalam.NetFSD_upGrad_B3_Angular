﻿using ProductService.DTOs;

namespace ProductService.Repositories.Interfaces;

public interface IProductRepository
{
    Task<PaginationResponseDto<ProductDto>>
        GetProductsAsync(
            string? search,
            int pageNumber,
            int pageSize);

    Task<ProductDto?> GetByIdAsync(int id);

    Task<ProductDto> AddAsync(ProductDto dto);
    Task<bool> UpdateAsync(ProductDto dto);

    Task<bool> DeleteAsync(int id);

    Task<bool> ReduceStockAsync(
    int productId,
    int quantity);
}