﻿using System.Net;
using System.Text.Json;

namespace ProductService.Middlewares;

// Middleware for handling global exceptions

public class ExceptionMiddleware
{
    // Handles next middleware request

    private readonly RequestDelegate _next;

    // Logger object for logging errors

    private readonly ILogger<ExceptionMiddleware>
        _logger;

    // Constructor injection

    public ExceptionMiddleware(
        RequestDelegate next,
        ILogger<ExceptionMiddleware> logger)
    {
        _next = next;

        _logger = logger;
    }

    // HANDLE REQUEST 
    // Executes request and catches exceptions

    public async Task InvokeAsync(
        HttpContext context)
    {
        try
        {
            // Continue request pipeline

            await _next(context);
        }
        catch (Exception ex)
        {
            // Log exception details

            _logger.LogError(
                ex,
                ex.Message);

            // Set response content type

            context.Response.ContentType =
                "application/json";

            // Set HTTP status code

            context.Response.StatusCode =
                (int)HttpStatusCode.InternalServerError;

            // Create error response object

            var response = new
            {
                statusCode =
                    context.Response.StatusCode,

                message =
                    "Internal Server Error",

                details =
                    ex.Message
            };

            // Convert object into JSON

            var jsonResponse =
                JsonSerializer.Serialize(response);

            // Return JSON error response

            await context.Response.WriteAsync(
                jsonResponse);
        }
    }
}