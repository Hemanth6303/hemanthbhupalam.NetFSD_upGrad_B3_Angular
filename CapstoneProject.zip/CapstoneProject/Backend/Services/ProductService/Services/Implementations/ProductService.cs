﻿using ProductService.DTOs;
using ProductService.Repositories.Interfaces;
using ProductService.Services.Interfaces;

namespace ProductService.Services.Implementations;

public class ProductService
    : IProductService
{
    private readonly IProductRepository
        _repository;

    public ProductService(
        IProductRepository repository)
    {
        _repository = repository;
    }

    // Get products

    public async Task<
        PaginationResponseDto<ProductDto>>
        GetProductsAsync(
            string? search,
            int pageNumber,
            int pageSize)
    {
        return await _repository.GetProductsAsync(
            search,
            pageNumber,
            pageSize);
    }

    // Get product by id

    public async Task<ProductDto?>
        GetByIdAsync(int id)
    {
        return await _repository.GetByIdAsync(id);
    }

    // Add product

    public async Task<ProductDto>
    AddAsync(ProductDto dto)
    {
        return await _repository.AddAsync(dto);
    }

    // Update product

    public async Task<bool>
        UpdateAsync(ProductDto dto)
    {
        return await _repository.UpdateAsync(dto);
    }

    // Delete product

    public async Task<bool>
        DeleteAsync(int id)
    {
        return await _repository.DeleteAsync(id);
    }


    public async Task<bool>
ReduceStockAsync(
    int productId,
    int quantity)
    {
        return await _repository
            .ReduceStockAsync(
                productId,
                quantity);
    }
}