﻿
using System.ComponentModel.DataAnnotations;

namespace ProductService.DTOs;

public class ProductDto
{
    public int ProductId { get; set; }

    [Required(ErrorMessage = "Product name is required")]
    [MinLength(3,
        ErrorMessage = "Product name must be at least 3 characters")]
    public string Name { get; set; } = string.Empty;

    [Required(ErrorMessage = "Description is required")]
    [MinLength(10,
        ErrorMessage = "Description must be at least 10 characters")]
    public string Description { get; set; }
        = string.Empty;

    [Range(1, 1000000,
        ErrorMessage = "Price must be greater than 0")]
    public decimal Price { get; set; }

    [Required(ErrorMessage = "Image URL is required")]
    public string ImageUrl { get; set; }
        = string.Empty;

    [Range(0, 10000,
        ErrorMessage = "Stock cannot be negative")]
    public int Stock { get; set; }

  

    [Required(ErrorMessage = "Category name is required")]
    [MinLength(3,
        ErrorMessage = "Category name must be at least 3 characters")]
    public string CategoryName { get; set; }
        = string.Empty;
}