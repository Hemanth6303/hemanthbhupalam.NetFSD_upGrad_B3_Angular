﻿using AuthService.DTOs;
using AuthService.Entities;
using AuthService.Helpers;
using AuthService.Repositories.Interfaces;
using AuthService.Services.Interfaces;

namespace AuthService.Services
{
    // Service class for authentication operations

    public class AuthService1 : IAuthService
    {
        // User repository object

        private readonly IUserRepository _repo;

        // JWT helper object

        private readonly JwtHelper _jwt;

        // Constructor injection

        public AuthService1(
            IUserRepository repo,
            JwtHelper jwt)
        {
            _repo = repo;
            _jwt = jwt;
        }

        // ================= REGISTER USER =================
        // Registers new user into database

        public async Task<string> RegisterAsync(RegisterDto dto)
        {
            // Check whether user already exists

            var existing = await _repo.GetByEmailAsync(dto.Email);

            if (existing != null)
                throw new Exception("User already exists");

            // Create new user object

            var user = new User
            {
                // UserId = Guid.NewGuid(),

                Name = dto.Name,

                Email = dto.Email,

                // Encrypt password using BCrypt

                PasswordHash =
                    BCrypt.Net.BCrypt.HashPassword(dto.Password)
            };

            // Save user into database

            await _repo.AddAsync(user);

            // Generate JWT token

            return _jwt.GenerateToken(user);
        }

        //  LOGIN USER 
        // Validates user credentials

        public async Task<string> LoginAsync(LoginDto dto)
        {
            // Find user using email

            var user =
                await _repo.GetByEmailAsync(dto.Email);

            // Validate password

            if (user == null ||
                !BCrypt.Net.BCrypt.Verify(
                    dto.Password,
                    user.PasswordHash))

                throw new Exception("Invalid credentials");

            // Generate JWT token

            return _jwt.GenerateToken(user);
        }
    }
}