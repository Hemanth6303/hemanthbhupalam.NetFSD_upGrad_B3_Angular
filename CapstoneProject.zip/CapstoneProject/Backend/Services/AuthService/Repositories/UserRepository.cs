﻿using AuthService.Data;
using AuthService.Entities;
using AuthService.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace AuthService.Repositories
{
    // Repository class for User table operations

    public class UserRepository : IUserRepository
    {
        // Database context object

        private readonly AuthDbContext _context;

        // Constructor injection

        public UserRepository(AuthDbContext context)
        {
            _context = context;
        }

        // GET USER BY EMAIL 
        // Returns user details using email

        public async Task<User?> GetByEmailAsync(string email)
            => await _context.Users.FirstOrDefaultAsync(x => x.Email == email);

        // ADD USER 
        // Adds new user into database

        public async Task AddAsync(User user)
        {
            // Add user into Users table

            await _context.Users.AddAsync(user);

            // Save changes into database

            await _context.SaveChangesAsync();
        }
    }
}