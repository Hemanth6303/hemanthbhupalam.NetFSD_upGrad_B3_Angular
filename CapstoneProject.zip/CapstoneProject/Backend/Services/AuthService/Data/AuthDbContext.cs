﻿using AuthService.Entities;
using Microsoft.EntityFrameworkCore;

namespace AuthService.Data
{
    public class AuthDbContext : DbContext
    {
        public AuthDbContext(DbContextOptions<AuthDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users => Set<User>();
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {


            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<User>().HasData(
           new User
           {
               UserId = 1,
               Name = "Admin",
               Email = "admin@gmail.com",
               PasswordHash = "$2a$11$7.PSaQxw4V8qxxUniB2Q6u2JKVzvgoujznRMWa6Y1CEAxQG4wDa36",
               //Console.WriteLine(BCrypt.Net.BCrypt.HashPassword("Admin@123"));

               Role = "Admin"
           }
           );
        }
    }
}
