﻿using AuthService.Data;
using AuthService.DTOs;
using AuthService.Entities;
using AuthService.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AuthService.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly AuthDbContext _context;

    private readonly JwtHelper _jwtHelper;

    private readonly ILogger<AuthController> _logger;

    public AuthController(
        AuthDbContext context,
        JwtHelper jwtHelper,
        ILogger<AuthController> logger)
    {
        _context = context;
        _jwtHelper = jwtHelper;
        _logger = logger;
    }

    // REGISTER 

    [HttpPost("register")]
    public async Task<IActionResult> Register(RegisterDto dto)
    {
        _logger.LogInformation(
            "Register request for {Email}",
            dto.Email);

        bool exists = await _context.Users
            .AnyAsync(x => x.Email == dto.Email);

        if (exists)
        {
            return BadRequest(new
            {
                message = "Email already exists"
            });
        }

        var user = new User
        {
            Name = dto.Name,

            Email = dto.Email,

            PasswordHash =
                BCrypt.Net.BCrypt.HashPassword(dto.Password),

            Role = "Customer"
        };

        _context.Users.Add(user);

        await _context.SaveChangesAsync();

        return Ok(new
        {
            message = "Registration Successful"
        });
    }

    //  LOGIN 

    [HttpPost("login")]
    public async Task<IActionResult> Login(LoginDto dto)
    {
        _logger.LogInformation(
            "Login request for {Email}",
            dto.Email);

        var user = await _context.Users
            .FirstOrDefaultAsync(
                x => x.Email == dto.Email);

        if (user == null)
        {
            return Unauthorized(new
            {
                message = "Invalid Email or Password"
            });
        }

        bool validPassword =
            BCrypt.Net.BCrypt.Verify(
                dto.Password,
                user.PasswordHash);

        if (!validPassword)
        {
            return Unauthorized(new
            {
                message = "Invalid Email or Password"
            });
        }

        string token =
            _jwtHelper.GenerateToken(user);

        var response = new AuthResponseDto
        {
            Token = token,

            UserId = user.UserId,

            Name = user.Name,

            Email = user.Email,

            Role = user.Role
        };

        return Ok(response);
    }




    //  GET USERS 

    [Authorize(Roles = "Admin")]
    [HttpGet]
    public async Task<IActionResult>
        GetUsers()
    {
        var users =
            await _context.Users
            .Select(x => new
            {
                x.UserId,

                x.Name,

                x.Email,

                x.Role
            })
            .ToListAsync();

        return Ok(users);
    }

    // UPDATE ROLE 

    [Authorize(Roles = "Admin")]
    [HttpPut("{id}/role")]
    public async Task<IActionResult>
        UpdateRole(
            int id,
            [FromBody]
            UpdateRoleDto dto)
    {
        var user =
            await _context.Users
            .FirstOrDefaultAsync(
                x => x.UserId == id);

        if (user == null)
        {
            return NotFound(new
            {
                message =
                    "User not found"
            });
        }

        user.Role = dto.Role;

        await _context.SaveChangesAsync();

        return Ok(new
        {
            message =
                "Role updated successfully"
        });
    }



}