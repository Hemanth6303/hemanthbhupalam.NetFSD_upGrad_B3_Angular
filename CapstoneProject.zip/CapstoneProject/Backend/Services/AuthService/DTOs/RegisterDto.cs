﻿using System.ComponentModel.DataAnnotations;

    namespace AuthService.DTOs
    {
        public class RegisterDto
        {
            [Required(ErrorMessage = "Name is required")]
            [MinLength(3, ErrorMessage = "Name must be at least 3 characters")]
            public string Name { get; set; } = default!;

            [Required(ErrorMessage = "Email is required")]
            [EmailAddress(ErrorMessage = "Invalid email format")]
            public string Email { get; set; } = default!;

            [Required(ErrorMessage = "Password is required")]
            [MinLength(6, ErrorMessage = "Password must be at least 6 characters")]
            public string Password { get; set; } = default!;
        }
    }

