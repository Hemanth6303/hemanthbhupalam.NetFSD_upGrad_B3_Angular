﻿using System.ComponentModel.DataAnnotations;

namespace AuthService.DTOs;
public class UpdateRoleDto
{
    [Required(ErrorMessage = "Role is required")]

    [RegularExpression(
        "^(Admin|Customer)$",
        ErrorMessage = "Role must be Admin,Customer"
    )]

    public string Role { get; set; } = string.Empty;
}