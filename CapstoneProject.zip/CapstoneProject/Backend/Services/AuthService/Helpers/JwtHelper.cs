﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using AuthService.Entities;
using Microsoft.IdentityModel.Tokens;

namespace AuthService.Helpers;

// Helper class for JWT token generation

public class JwtHelper
{
    // Configuration object

    private readonly IConfiguration _configuration;

    // Constructor injection

    public JwtHelper(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    // GENERATE JWT TOKEN 
    // Creates JWT token for authenticated user

    public string GenerateToken(User user)
    {
        // User claims stored inside token

        var claims = new[]
        {
            new Claim(
                ClaimTypes.NameIdentifier,
                user.UserId.ToString()),

            new Claim(
                ClaimTypes.Name,
                user.Name),

            new Claim(
                ClaimTypes.Email,
                user.Email),

            new Claim(
                ClaimTypes.Role,
                user.Role)
        };

        // Secret key for token encryption

        var key = new SymmetricSecurityKey(
            Encoding.UTF8.GetBytes(
                _configuration["Jwt:Key"]!));

        // Signing credentials using SHA256 algorithm

        var credentials = new SigningCredentials(
            key,
            SecurityAlgorithms.HmacSha256);

        // Create JWT token

        var token = new JwtSecurityToken(
            issuer: _configuration["Jwt:Issuer"],

            audience: _configuration["Jwt:Audience"],

            claims: claims,

            // Token expiry time

            expires: DateTime.Now.AddDays(1),

            signingCredentials: credentials);

        // Convert token object into string

        return new JwtSecurityTokenHandler()
            .WriteToken(token);
    }
}