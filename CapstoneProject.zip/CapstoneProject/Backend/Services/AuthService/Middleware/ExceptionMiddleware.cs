﻿using System.Net;
using System.Text.Json;

namespace AuthService.Middlewares;

// Middleware for handling global exceptions

public class ExceptionMiddleware
{
    // Handles next middleware request

    private readonly RequestDelegate _next;

    // Logger object for logging errors

    private readonly ILogger<ExceptionMiddleware> _logger;

    // Constructor injection

    public ExceptionMiddleware(
        RequestDelegate next,
        ILogger<ExceptionMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    // HANDLE REQUEST 
    // Executes request and catches exceptions

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            // Move request to next middleware

            await _next(context);
        }
        catch (Exception ex)
        {
            // Log exception details

            _logger.LogError(ex, ex.Message);

            // Set response content type

            context.Response.ContentType = "application/json";

            // Set HTTP status code

            context.Response.StatusCode =
                (int)HttpStatusCode.InternalServerError;

            // Create error response object

            var response = new
            {
                StatusCode = context.Response.StatusCode,

                Message = "Internal Server Error",

                Details = ex.Message
            };

            // Return JSON error response

            await context.Response.WriteAsync(
                JsonSerializer.Serialize(response));
        }
    }
}